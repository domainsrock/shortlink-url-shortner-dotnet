﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data.SqlClient;

/// <summary>
/// this asp.net program is written in C#
/// this asp.net program is written by PRAVEEN SAHU
/// this asp.net program's owner is DOMAINSROCK INDIA
/// this asp.net program is copyright and reserved all rights
/// contact developer: developer.projectsupport@domainsrock.in
/// www.domainsrock.in | www.domainsrock.com | www.domainsrock.info
/// </summary>
public partial class shortlinkpro : System.Web.UI.Page
{
    string longurl, longurlmanual, shortcodemanual, AuthUsername = "null", AuthPassword = "null";
    bool EnablePageAccess = false; string DBSource;
    protected void Page_Load(object sender, EventArgs e)
    {
        DBSource = DatabaseControls.DBCnSource();
        SqlConnection SQLCn = new SqlConnection(DBSource);
        if (!DatabaseControls.IsDataExist(MasterSettings.Function_ShortLinkPro)) { panel_recentshortlinkpro.Visible = false; }

        // this function will check that user is logged-in or not
        HttpCookieCollection Col = Request.Cookies;
        if (Col != null)
        {
            HttpCookie CoLogin = null;
            for (int c = 0; c < Col.Count; c++)
            {
                CoLogin = Col[c];
                if (CoLogin.Name == MasterSettings.SafeLoginValidation + ".Username") { AuthUsername = PortalControls.DecodePasswordFromBase64(CoLogin.Value.ToString()); };
                if (CoLogin.Name == MasterSettings.SafeLoginValidation + ".Password") { AuthPassword = PortalControls.DecodePasswordFromBase64(CoLogin.Value.ToString()); };
                if (AuthUsername != "null" && AuthPassword != "null")
                {
                    if (AuthUsername == PortalConfiguration.admin_username && AuthPassword == PortalConfiguration.admin_password) { EnablePageAccess = true; break; };
                    break;
                }
                else if (c == Col.Count - 1) { Response.Redirect(MasterSettings.PortalPage_Home); break; }
            }
        };

        if (EnablePageAccess)
        {
            if (!DatabaseControls.IsTableExist(MasterSettings.Function_ShortLinkPro)) { button_shortlinkpro_genmanual.Enabled = false; div_error.Visible = true; div_information.Visible = div_success.Visible = div_warning.Visible = false; label_error.Text = "ShortLinkPro Function is not Installed... <a href='" + MasterSettings.PortalPage_AdminPanel + "'>Click Here to Install this Function</a>"; };
            panel_shortlinkpro_genmanual.Visible = true; panel_showshortlinkpro.Visible = false;

            try
            {
                string SQLQuery = "SELECT shortlink_id,shortlink_visits,shortlink_regdate,shortlink_realurl from " + MasterSettings.Function_ShortLinkPro + " order by shortlink_regdate desc";
                SQLCn.Open();
                SqlCommand SQLCmd = new SqlCommand(SQLQuery, SQLCn);
                SqlDataReader SQLDR = SQLCmd.ExecuteReader();
                int count = 0;

                // table header elements
                TableHeaderRow THR = new TableHeaderRow();
                table_recentshortlinkpro.Rows.Add(THR);
                TableHeaderCell THC1 = new TableHeaderCell();
                THC1.Text = "ShortCode";
                THR.Cells.Add(THC1);
                TableHeaderCell THC2 = new TableHeaderCell();
                THC2.Text = "Visits";
                THR.Cells.Add(THC2);
                TableHeaderCell THC3 = new TableHeaderCell();
                THC3.Text = "Date";
                THR.Cells.Add(THC3);
                TableHeaderCell THC4 = new TableHeaderCell();
                THC4.Text = "Action";
                THR.Cells.Add(THC4);

                while (SQLDR.Read())
                {
                    if (count < 10)
                    {
                        // table content elements
                        TableRow TR = new TableRow();
                        table_recentshortlinkpro.Rows.Add(TR);
                        TableCell TC1 = new TableCell();
                        TC1.Text = SQLDR["shortlink_id"].ToString();
                        TR.Cells.Add(TC1);
                        TableCell TC2 = new TableCell();
                        TC2.Text = SQLDR["shortlink_visits"].ToString();
                        TR.Cells.Add(TC2);
                        TableCell TC3 = new TableCell();
                        TC3.Text = SQLDR["shortlink_regdate"].ToString();
                        TR.Cells.Add(TC3);
                        TableCell TC4 = new TableCell();
                        TC4.Text = "<a href='" + PortalConfiguration.shortlink_homepath + "?" + PortalConfiguration.shortlinkpro_validator + "=" + SQLDR["shortlink_id"].ToString() + "' class='btn btn-xs btn-success' target='_blank'><font color='white'>Visit</font></a>";
                        TR.Cells.Add(TC4);
                        count = count + 1;
                    }
                    else { break; }
                }
            }
            catch (Exception) { }
            finally { SQLCn.Close(); }
        };
    }
    protected void button_shortlinkpro_genmanual_Click(object sender, EventArgs e)
    {
        if (DatabaseControls.IsTableExist(MasterSettings.Function_ShortLinkPro))
        {
            if (DatabaseControls.ValidateInputValue(input_shortlinkmanual.Text))
            {
                if (!DatabaseControls.Validate_ShortLinkPro_ShortId(input_shortlinkmanual.Text))
                {
                    if (input_longlinkmanual.Text.Length > 10)
                    {
                        longurlmanual = input_longlinkmanual.Text;
                        shortcodemanual = input_shortlinkmanual.Text;
                        panel_shortlinkpro_genmanual.Visible = false;
                        panel_showshortlinkpro.Visible = true;

                        if (DatabaseControls.InsertValues_ShortLinkProManual(shortcodemanual, longurlmanual))
                        {
                            string sharelink = PortalConfiguration.shortlink_homepath + "?" + PortalConfiguration.shortlinkpro_validator + "=" + shortcodemanual + "";
                            string sharelink_fb = "https://www.facebook.com/sharer/sharer.php?u=" + sharelink + "";
                            string sharelink_tw = "https://twitter.com/home?status=Please Check This Link! I've Shared Something Special with You. " + sharelink + "";
                            string sharelink_gp = "https://plus.google.com/share?url=" + sharelink + "";
                            string sharelink_wa = "whatsapp://send?text=Please Check This Link! I've Shared Something Special with You. " + sharelink + "";
                            string sharelink_tg = "https://telegram.me/share/url?url=" + sharelink + "";
                            sharelink_facebook.NavigateUrl = sharelink_fb;
                            sharelink_twitter.NavigateUrl = sharelink_tw;
                            sharelink_googleplus.NavigateUrl = sharelink_gp;
                            sharelink_whatsapp.NavigateUrl = sharelink_wa;
                            sharelink_telegram.NavigateUrl = sharelink_tg;

                            output_showgenlink.Text = sharelink;
                            link_testlink.NavigateUrl = sharelink;

                            div_warning.Visible = div_information.Visible = div_error.Visible = false;
                            div_success.Visible = true; label_success.Text = "ShortLink Pro Generated Successfully...";
                        }
                        else { div_error.Visible = true; label_error.Text = "Unable to Generated ShortLink due to Some Error..."; div_information.Visible = div_success.Visible = div_warning.Visible = false; }
                    }
                    else { div_error.Visible = true; label_error.Text = "Invalid Long URL"; div_information.Visible = div_success.Visible = div_warning.Visible = false; }
                }
                else { div_error.Visible = true; label_error.Text = "ShortCode Already Used! Please Use Another Valid ShortCode"; div_information.Visible = div_success.Visible = div_warning.Visible = false; }
            }
            else { div_error.Visible = true; label_error.Text = "Invalid ShortCode! Please Use Another Valid ShortCode"; div_information.Visible = div_success.Visible = div_warning.Visible = false; }
        };
    }
}