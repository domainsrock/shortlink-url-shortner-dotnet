﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Data.SqlClient;

/// <summary>
/// this asp.net program is written in C#
/// this asp.net program is written by PRAVEEN SAHU
/// this asp.net program's owner is DOMAINSROCK INDIA
/// this asp.net program is copyright and reserved all rights
/// contact developer: developer.projectsupport@domainsrock.in
/// www.domainsrock.in | www.domainsrock.com | www.domainsrock.info
/// </summary>
public partial class index : System.Web.UI.Page
{
    string shortcode, shortcodepro, longurl, page, errorpath, DBSource;
    protected void Page_Load(object sender, EventArgs e)
    {
        //string originalPath = HttpContext.Current.Request.Path.ToLower();
        //div_error.Visible = true; label_error.Text = originalPath;

        DBSource = DatabaseControls.DBCnSource();
        SqlConnection SQLCn = new SqlConnection(DBSource);

        panel_genslink.Visible = true; panel_redirect.Visible = panel_showgenlink.Visible = panel_pagemanager.Visible = false;
        if (!DatabaseControls.IsTableExist(MasterSettings.Function_ShortLink)) { button_genslink.Enabled = false; }
        if (!DatabaseControls.IsDataExist(MasterSettings.Function_ShortLink)) { panel_recentshortlink.Visible = false; }

        // redirect function for shortlink - start
        try { shortcode = Request.QueryString["" + PortalConfiguration.shortlink_validator + ""].ToString(); }
        catch (Exception) { shortcode = "null"; }

        if (shortcode != "null")
        {
            if (DatabaseControls.Validate_ShortLink_ShortId(shortcode))
            {
                DatabaseControls.UpdateValue_ShortLink_Visits(shortcode);
                int gowait = PortalConfiguration.shortlink_redirectwait;
                panel_redirect.Visible = true; panel_genslink.Visible = panel_showgenlink.Visible = panel_pagemanager.Visible = false;
                Response.AppendHeader("Refresh", "" + gowait + ",url=" + DatabaseControls.GetValues_ShortLink_RealURL(shortcode) + "");
                label_redirect.Text = "You will now be Redirected to Original Page in " + gowait + " Seconds";
            };
        };
        // redirect function for shortlink - end

        // redirect function for shortlink pro - start
        try { shortcodepro = Request.QueryString["" + PortalConfiguration.shortlinkpro_validator + ""].ToString(); }
        catch (Exception) { shortcodepro = "null"; }

        if (shortcodepro != "null")
        {
            if (DatabaseControls.Validate_ShortLinkPro_ShortId(shortcodepro))
            {
                DatabaseControls.UpdateValue_ShortLinkPro_Visits(shortcodepro);
                int gowaitpro = PortalConfiguration.shortlinkpro_redirectwait;
                panel_redirect.Visible = true; panel_genslink.Visible = panel_showgenlink.Visible = panel_pagemanager.Visible = false;
                Response.AppendHeader("Refresh", "" + gowaitpro + ",url=" + DatabaseControls.GetValues_ShortLinkPro_RealURL(shortcodepro) + "");
                label_redirect.Text = "You will now be Redirected to Original Page in " + gowaitpro + " Seconds";
            };
        };
        // redirect function for shortlink pro - end

        // pagemanager function - start
        try { page = Request.QueryString["page"].ToString(); }
        catch (Exception) { page = "null"; }

        if (page != "null")
        {
            if (DatabaseControls.Validate_PageManager_PageId(page))
            {
                DatabaseControls.Update_PageManager_PageViews(page);
                pagefunction_pagetitle.Text = DatabaseControls.GetValues_PageManager_PageTitle(page);
                pagefunction_pagecontent.Text = DatabaseControls.GetValues_PageManager_PageContent(page);
                panel_pagemanager.Visible = true; panel_genslink.Visible = panel_showgenlink.Visible = panel_redirect.Visible = panel_recentshortlink.Visible = false;
            };
        };
        // pagemanager function - end

        // aspxerrorpath function - start
        try { errorpath = Request.QueryString["aspxerrorpath"].ToString(); }
        catch (Exception) { errorpath = "null"; }
        if (errorpath != "null") { Response.Redirect(MasterSettings.PortalPage_Home); };
        // aspxerrorpath function - end



        try
        {
            string SQLQuery = "SELECT shortlink_id,shortlink_visits,shortlink_regdate,shortlink_realurl from " + MasterSettings.Function_ShortLink + " order by shortlink_regdate desc";
            SQLCn.Open();
            SqlCommand SQLCmd = new SqlCommand(SQLQuery, SQLCn);
            SqlDataReader SQLDR = SQLCmd.ExecuteReader();
            int count = 0;

            // table header elements
            TableHeaderRow THR = new TableHeaderRow();
            table_recentshortlink.Rows.Add(THR);
            TableHeaderCell THC1 = new TableHeaderCell();
            THC1.Text = "ShortCode";
            THR.Cells.Add(THC1);
            TableHeaderCell THC2 = new TableHeaderCell();
            THC2.Text = "Visits";
            THR.Cells.Add(THC2);
            TableHeaderCell THC3 = new TableHeaderCell();
            THC3.Text = "Date";
            THR.Cells.Add(THC3);
            TableHeaderCell THC4 = new TableHeaderCell();
            THC4.Text = "Action";
            THR.Cells.Add(THC4);

            while (SQLDR.Read())
            {
                if (count < 10)
                {
                    // table content elements
                    TableRow TR = new TableRow();
                    table_recentshortlink.Rows.Add(TR);
                    TableCell TC1 = new TableCell();
                    TC1.Text = SQLDR["shortlink_id"].ToString();
                    TR.Cells.Add(TC1);
                    TableCell TC2 = new TableCell();
                    TC2.Text = SQLDR["shortlink_visits"].ToString();
                    TR.Cells.Add(TC2);
                    TableCell TC3 = new TableCell();
                    TC3.Text = SQLDR["shortlink_regdate"].ToString();
                    TR.Cells.Add(TC3);
                    TableCell TC4 = new TableCell();
                    TC4.Text = "<a href='" + PortalConfiguration.shortlink_homepath + "?" + PortalConfiguration.shortlink_validator + "=" + SQLDR["shortlink_id"].ToString() + "' class='btn btn-xs btn-success' target='_blank'><font color='white'>Visit</font></a>";
                    TR.Cells.Add(TC4);
                    count = count + 1;
                }
                else { break; }
            }
        }
        catch (Exception) { }
        finally { SQLCn.Close(); }
    }
    protected void button_genslink_Click(object sender, EventArgs e)
    {
        if (DatabaseControls.IsTableExist(MasterSettings.Function_ShortLink))
        {
            if (input_longlink.Text.Length > 10)
            {                
                longurl = input_longlink.Text;
                panel_genslink.Visible = false;
                panel_showgenlink.Visible = true;

                string shortcode = DatabaseControls.InsertValues_ShortLink(longurl);
                string sharelink = PortalConfiguration.shortlink_homepath + "?" + PortalConfiguration.shortlink_validator + "=" + shortcode + "";
                string sharelink_fb = "https://www.facebook.com/sharer/sharer.php?u=" + sharelink + "";
                string sharelink_tw = "https://twitter.com/home?status=Please Check This Link! I've Shared Something Special with You. " + sharelink + "";
                string sharelink_gp = "https://plus.google.com/share?url=" + sharelink + "";
                string sharelink_wa = "whatsapp://send?text=Please Check This Link! I've Shared Something Special with You. " + sharelink + "";
                string sharelink_tg = "https://telegram.me/share/url?url=" + sharelink + "";
                sharelink_facebook.NavigateUrl = sharelink_fb;
                sharelink_twitter.NavigateUrl = sharelink_tw;
                sharelink_googleplus.NavigateUrl = sharelink_gp;
                sharelink_whatsapp.NavigateUrl = sharelink_wa;
                sharelink_telegram.NavigateUrl = sharelink_tg;

                output_showgenlink.Text = sharelink;
                link_testlink.NavigateUrl = output_showgenlink.Text;
                div_warning.Visible = div_information.Visible = div_error.Visible = false;
                div_success.Visible = true; label_success.Text = "ShortLink Generated Successfully...";
            }
            else { div_error.Visible = true; label_error.Text = "Invalid URL"; div_information.Visible = div_success.Visible = div_warning.Visible = false; }
        };
    }
}