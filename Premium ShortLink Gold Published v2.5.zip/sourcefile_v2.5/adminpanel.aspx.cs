﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

/// <summary>
/// this asp.net program is written in C#
/// this asp.net program is written by PRAVEEN SAHU
/// this asp.net program's owner is DOMAINSROCK INDIA
/// this asp.net program is copyright and reserved all rights
/// contact developer: developer.projectsupport@domainsrock.in
/// www.domainsrock.in | www.domainsrock.com | www.domainsrock.info
/// </summary>
public partial class adminpanel : System.Web.UI.Page
{
    string AuthUsername = "null", AuthPassword = "null";
    bool EnablePageAccess = false;
    protected void Page_Load(object sender, EventArgs e)
    {
        // this function will check that user is logged-in or not
        HttpCookieCollection Col = Request.Cookies;
        if (Col != null)
        {
            HttpCookie CoLogin = null;
            for (int c = 0; c < Col.Count; c++)
            {
                CoLogin = Col[c];
                if (CoLogin.Name == MasterSettings.SafeLoginValidation + ".Username") { AuthUsername = PortalControls.DecodePasswordFromBase64(CoLogin.Value.ToString()); };
                if (CoLogin.Name == MasterSettings.SafeLoginValidation + ".Password") { AuthPassword = PortalControls.DecodePasswordFromBase64(CoLogin.Value.ToString()); };
                if (AuthUsername != "null" && AuthPassword != "null")
                {
                    if (AuthUsername == PortalConfiguration.admin_username && AuthPassword == PortalConfiguration.admin_password) { EnablePageAccess = true; break; };
                    break;
                }
                else if (c == Col.Count - 1) { Response.Redirect(MasterSettings.PortalPage_Home); break; }
            }
        };

        if (DatabaseControls.IsTableExist(MasterSettings.Function_ShortLink)) { linkbutton_installshortlink.Enabled = false; linkbutton_installshortlink.Text = "<font color='green'>Installed</font>"; };
        if (DatabaseControls.IsTableExist(MasterSettings.Function_ShortLinkPro)) { linkbutton_installshortlinkpro.Enabled = false; linkbutton_installshortlinkpro.Text = "<font color='green'>Installed</font>"; };
        if (DatabaseControls.IsTableExist(MasterSettings.Function_PageManager)) { linkbutton_installpagemanager.Enabled = false; linkbutton_installpagemanager.Text = "<font color='green'>Installed</font>"; };
        if (DatabaseControls.IsTableExist(MasterSettings.Function_FooterMenu)) { linkbutton_installfootermenu.Enabled = false; linkbutton_installfootermenu.Text = "<font color='green'>Installed</font>"; };
    }
    protected void linkbutton_installshortlink_Click(object sender, EventArgs e)
    {
        if (DatabaseControls.NewTable_ShortLink())
        {
            linkbutton_installshortlink.Enabled = false; linkbutton_installshortlink.Text = "<font color='green'>Installed</font>";
            div_error.Visible = div_information.Visible = div_warning.Visible = false;
            div_success.Visible = true; label_success.Text = "ShortLink Function Installed Successfully...";
        }
        else
        {
            div_success.Visible = div_information.Visible = div_warning.Visible = false;
            div_error.Visible = true; label_error.Text = "ShortLink Function Installation Failed...";
        }
    }
    protected void linkbutton_installshortlinkpro_Click(object sender, EventArgs e)
    {
        if (DatabaseControls.NewTable_ShortLinkPro())
        {
            linkbutton_installshortlinkpro.Enabled = false; linkbutton_installshortlinkpro.Text = "<font color='green'>Installed</font>";
            div_error.Visible = div_information.Visible = div_warning.Visible = false;
            div_success.Visible = true; label_success.Text = "ShortLinkPro Function Installed Successfully...";
        }
        else
        {
            div_success.Visible = div_information.Visible = div_warning.Visible = false;
            div_error.Visible = true; label_error.Text = "ShortLinkPro Function Installation Failed...";
        }
    }
    protected void linkbutton_installpagemanager_Click(object sender, EventArgs e)
    {
        if (DatabaseControls.NewTable_PageManager())
        {
            linkbutton_installpagemanager.Enabled = false; linkbutton_installpagemanager.Text = "<font color='green'>Installed</font>";
            div_error.Visible = div_information.Visible = div_warning.Visible = false;
            div_success.Visible = true; label_success.Text = "PageManager Function Installed Successfully...";
        }
        else
        {
            div_success.Visible = div_information.Visible = div_warning.Visible = false;
            div_error.Visible = true; label_error.Text = "PageManager Function Installation Failed...";
        }
    }
    protected void linkbutton_installfootermenu_Click(object sender, EventArgs e)
    {
        if (DatabaseControls.NewTable_FooterMenu())
        {
            linkbutton_installfootermenu.Enabled = false; linkbutton_installfootermenu.Text = "<font color='green'>Installed</font>";
            div_error.Visible = div_information.Visible = div_warning.Visible = false;
            div_success.Visible = true; label_success.Text = "FooterMenu Function Installed Successfully...";
        }
        else
        {
            div_success.Visible = div_information.Visible = div_warning.Visible = false;
            div_error.Visible = true; label_error.Text = "FooterMenu Function Installation Failed...";
        }
    }
}