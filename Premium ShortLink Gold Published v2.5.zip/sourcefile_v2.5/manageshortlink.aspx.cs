﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class manageshortlink : System.Web.UI.Page
{
    string AuthUsername = "null", AuthPassword = "null"; int reqpage = 0;
    bool EnablePageAccess = false, DefaultView = false; string DBSource, action, shortcode;
    protected void Page_Load(object sender, EventArgs e)
    {
        DBSource = DatabaseControls.DBCnSource();
        SqlConnection SQLCn = new SqlConnection(DBSource);
        if (!DatabaseControls.IsDataExist(MasterSettings.Function_ShortLinkPro)) { panel_manageshortlinkpro.Visible = false; }
        if (!DatabaseControls.IsTableExist(MasterSettings.Function_ShortLinkPro)) { panel_manageshortlinkpro.Visible = false; div_error.Visible = true; div_information.Visible = div_success.Visible = div_warning.Visible = false; label_error.Text = "ShortLinkPro Function is not Installed... <a href='" + MasterSettings.PortalPage_AdminPanel + "'>Click Here to Install this Function</a>"; };

        try { reqpage = Convert.ToInt32(Request.QueryString["page"].ToString()); }
        catch (Exception) { reqpage = 1; }
        try { action = Request.QueryString["action"].ToString(); }
        catch (Exception) { action = "null"; }
        try { shortcode = Request.QueryString["shortcode"].ToString(); }
        catch (Exception) { shortcode = "null"; }

        // this function will check that user is logged-in or not
        HttpCookieCollection Col = Request.Cookies;
        if (Col != null)
        {
            HttpCookie CoLogin = null;
            for (int c = 0; c < Col.Count; c++)
            {
                CoLogin = Col[c];
                if (CoLogin.Name == MasterSettings.SafeLoginValidation + ".Username") { AuthUsername = PortalControls.DecodePasswordFromBase64(CoLogin.Value.ToString()); };
                if (CoLogin.Name == MasterSettings.SafeLoginValidation + ".Password") { AuthPassword = PortalControls.DecodePasswordFromBase64(CoLogin.Value.ToString()); };
                if (AuthUsername != "null" && AuthPassword != "null")
                {
                    if (AuthUsername == PortalConfiguration.admin_username && AuthPassword == PortalConfiguration.admin_password) { EnablePageAccess = true; break; };
                    break;
                }
                else if (c == Col.Count - 1) { Response.Redirect(MasterSettings.PortalPage_Home); break; }
            }
        };


        if (EnablePageAccess)
        {
            if (action == "edit" || action == "delete")
            {
                panel_manageshortlinkpro.Visible = false;
                if (DatabaseControls.Validate_ShortLinkPro_ShortId(shortcode))
                {
                    if (action == "edit")
                    {
                        panel_manageshortlinkpro.Visible = false;
                        panel_manageshortlinkpro_edit.Visible = true;
                        label_manageshortlinkpro_edit.Text = "ShortLink Pro Edit: " + shortcode + "";
                        if (!IsPostBack) { input_shortcode.Text = shortcode; input_visitlink.Text = DatabaseControls.GetValues_ShortLinkPro_RealURL(shortcode); };
                    }
                    else if (action == "delete")
                    {
                        panel_manageshortlinkpro.Visible = panel_manageshortlinkpro_edit.Visible = false;
                        panel_manageshortlinkpro_delete.Visible = true;
                        label_manageshortlinkpro_delete.Text = "ShortLink Pro Delete: " + shortcode + "";
                        if (!IsPostBack) { show_shortcode.Text = shortcode; show_visitlink.Text = DatabaseControls.GetValues_ShortLinkPro_RealURL(shortcode); };
                    };
                }
                else { panel_manageshortlinkpro.Visible = true; panel_manageshortlinkpro_edit.Visible = panel_manageshortlinkpro_delete.Visible = false; label_error.Text = "Unable to Perform Action! Requested URL doesn't Exist or Deleted..."; div_error.Visible = true; div_warning.Visible = div_success.Visible = div_information.Visible = false; }
            }
            else { panel_manageshortlinkpro.Visible = true; panel_manageshortlinkpro_edit.Visible = false; }


            // this function for pagination - start
            int countdata = DatabaseControls.CountData_ShortLinkPro();
            int countpage = countdata / 10;
            int countlpagedata = countdata % 10;
            int totalpage = countpage;
            if (countlpagedata > 0) { totalpage = countpage + 1; };

            int viewpage = reqpage;
            int nextpage = viewpage + 1;
            int prevpage = viewpage - 1;
            if (totalpage == 1) { pagination.Visible = pagination_first.Enabled = pagination_last.Enabled = pagination_next.Enabled = pagination_previous.Enabled = false; };
            // this function for pagination - end

            try
            {
                string SQLQuery = "SELECT shortlink_id,shortlink_visits,shortlink_regdate,shortlink_realurl from " + MasterSettings.Function_ShortLinkPro + " order by shortlink_regdate asc";
                SQLCn.Open();
                SqlCommand SQLCmd = new SqlCommand(SQLQuery, SQLCn);
                SqlDataReader SQLDR = SQLCmd.ExecuteReader();

                // table header elements
                TableHeaderRow THR = new TableHeaderRow();
                table_manageshortlinkpro.Rows.Add(THR);
                TableHeaderCell THC1 = new TableHeaderCell();
                THC1.Text = "ShortCode";
                THR.Cells.Add(THC1);
                TableHeaderCell THC2 = new TableHeaderCell();
                THC2.Text = "Visits";
                THR.Cells.Add(THC2);
                TableHeaderCell THC3 = new TableHeaderCell();
                THC3.Text = "Date";
                THR.Cells.Add(THC3);
                TableHeaderCell THC4 = new TableHeaderCell();
                THC4.Text = "Action";
                THR.Cells.Add(THC4);


                // below function will display list
                int lastcount = viewpage * 10;
                int firstcount = lastcount - 10;

                if (viewpage == 1)
                {
                    int count = 0;
                    while (SQLDR.Read())
                    {
                        if (count < 10)
                        {
                            // table content elements
                            TableRow TR = new TableRow();
                            table_manageshortlinkpro.Rows.Add(TR);
                            TableCell TC1 = new TableCell();
                            TC1.Text = SQLDR["shortlink_id"].ToString();
                            TR.Cells.Add(TC1);
                            TableCell TC2 = new TableCell();
                            TC2.Text = SQLDR["shortlink_visits"].ToString();
                            TR.Cells.Add(TC2);
                            TableCell TC3 = new TableCell();
                            TC3.Text = SQLDR["shortlink_regdate"].ToString();
                            TR.Cells.Add(TC3);

                            string btnvisit = "<a href='" + PortalConfiguration.shortlink_homepath + "?" + PortalConfiguration.shortlinkpro_validator + "=" + SQLDR["shortlink_id"].ToString() + "' class='btn btn-xs btn-primary' target='_blank'><font color='white'>Visit</font></a>";
                            string btnedit = "<a href='manageshortlink.aspx?action=edit&shortcode=" + SQLDR["shortlink_id"].ToString() + "' class='btn btn-xs btn-success'><font color='white'>Edit</font></a>";
                            string btndelete = "<a href='manageshortlink.aspx?action=delete&shortcode=" + SQLDR["shortlink_id"].ToString() + "' class='btn btn-xs btn-danger'><font color='white'>Delete</font></a>";

                            TableCell TC4 = new TableCell();
                            TC4.Text = btnvisit + " " + btnedit + " " + btndelete;
                            TR.Cells.Add(TC4);
                            count = count + 1;
                        }
                        else { break; }
                    }
                    pagination_first.Enabled = pagination_previous.Enabled = false;
                    pagination_next.NavigateUrl = "?page=" + nextpage + "";
                    pagination_last.NavigateUrl = "?page=" + totalpage + "";
                }
                else
                {
                    int count = 0;
                    while (SQLDR.Read())
                    {
                        if (count < firstcount) { count = count + 1; }
                        else if (count < lastcount)
                        {

                            // table content elements
                            TableRow TR = new TableRow();
                            table_manageshortlinkpro.Rows.Add(TR);
                            TableCell TC1 = new TableCell();
                            TC1.Text = SQLDR["shortlink_id"].ToString();
                            TR.Cells.Add(TC1);
                            TableCell TC2 = new TableCell();
                            TC2.Text = SQLDR["shortlink_visits"].ToString();
                            TR.Cells.Add(TC2);
                            TableCell TC3 = new TableCell();
                            TC3.Text = SQLDR["shortlink_regdate"].ToString();
                            TR.Cells.Add(TC3);

                            string btnvisit = "<a href='" + PortalConfiguration.shortlink_homepath + "?" + PortalConfiguration.shortlinkpro_validator + "=" + SQLDR["shortlink_id"].ToString() + "' class='btn btn-xs btn-primary' target='_blank'><font color='white'>Visit</font></a>";
                            string btnedit = "<a href='manageshortlink.aspx?action=edit&shortcode=" + SQLDR["shortlink_id"].ToString() + "' class='btn btn-xs btn-success'><font color='white'>Edit</font></a>";
                            string btndelete = "<a href='manageshortlink.aspx?action=delete&shortcode=" + SQLDR["shortlink_id"].ToString() + "' class='btn btn-xs btn-danger'><font color='white'>Delete</font></a>";

                            TableCell TC4 = new TableCell();
                            TC4.Text = btnvisit + " " + btnedit + " " + btndelete;
                            TR.Cells.Add(TC4);
                            count = count + 1;
                        }
                        else { break; }
                    }
                    pagination_previous.NavigateUrl = "?page=" + prevpage + "";
                    pagination_next.NavigateUrl = "?page=" + nextpage + "";
                    pagination_last.NavigateUrl = "?page=" + totalpage + "";
                    if (viewpage == totalpage) { pagination_next.Enabled = pagination_last.Enabled = false; };
                }
            }
            catch (Exception) { }
            finally { SQLCn.Close(); }
        }
    }
    protected void button_updateshortlink_Click(object sender, EventArgs e)
    {
        if (shortcode == input_shortcode.Text || !DatabaseControls.Validate_ShortLinkPro_ShortId(input_shortcode.Text))
        {
            if (DatabaseControls.UpdateValue_ShortLinkPro(shortcode, input_shortcode.Text, input_visitlink.Text))
            {
                label_success.Text = "ShortLink Updated Successfully...";
                div_success.Visible = true; div_warning.Visible = div_error.Visible = div_information.Visible = false;
                panel_manageshortlinkpro_edit.Visible = false; panel_manageshortlinkpro.Visible = true;
            }
            else { label_error.Text = "Unable to Update ShortLink due to Some Technical Issue!"; div_error.Visible = true; div_warning.Visible = div_success.Visible = div_information.Visible = false; }
        }
        else { label_error.Text = "ShortCode Provided by You is Already Exists! Please Provide Another ShortCode..."; div_error.Visible = true; div_warning.Visible = div_success.Visible = div_information.Visible = false; }
    }
    protected void button_deleteshortlink_Click(object sender, EventArgs e)
    {
        if (DatabaseControls.DeleteValue_ShortLinkPro(shortcode))
        {
            label_success.Text = "ShortLink Deleted Successfully...";
            div_success.Visible = true; div_warning.Visible = div_error.Visible = div_information.Visible = false;
            panel_manageshortlinkpro_delete.Visible = false; panel_manageshortlinkpro.Visible = true;
        }
        else { label_error.Text = "Failed to Delete ShortLink..."; div_error.Visible = true; div_warning.Visible = div_success.Visible = div_information.Visible = false; }
    }
}