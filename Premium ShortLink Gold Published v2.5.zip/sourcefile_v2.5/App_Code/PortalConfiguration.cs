﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// this asp.net program is written in C#
/// this asp.net program is written by PRAVEEN SAHU
/// this asp.net program's owner is DOMAINSROCK INDIA
/// this asp.net program is copyright and reserved all rights
/// contact developer: developer.projectsupport@domainsrock.in
/// www.domainsrock.in | www.domainsrock.com | www.domainsrock.info
/// </summary>
public class PortalConfiguration
{
    // website configuration
    public static string website_logo = "images/logo.png"; // insert url of your website logo
    public static string website_name = "Free ShortLink"; // insert your website name
    public static string website_title = "Free URL Shortner | Free Link Shortner | Short Any Long URL or Link with Us"; // insert your website title
    public static string website_domain = "url9.pro"; // insert your website domain name only (without http:// or https://)
    public static string website_keyword = "short link, short url, shrink url, url shortner, link shortner, free url shortner, free link shortner"; // insert your website keywords
    public static string website_description = "getting bored with long url or always forgot url and missed some data from url, just get shortlink from us"; // insert your website description

    // admin login configuration
    public static string admin_username = "admin"; // insert admin username of website portal
    public static string admin_password = "admin"; // insert admin password of website portal

    // website shortlink configuration
    public static int shortlink_redirectwait = 10; // please insert value in seconds in which free shortlink redirect
    public static int shortlinkpro_redirectwait = 3; // please insert value in seconds in which free shortlink redirect
    public static string shortlink_validator = "id"; // please insert value of free shortlink validator, must be different from below shortlink_shortlinkpro_validator
    public static string shortlinkpro_validator = "go"; // please insert value of pro shortlink validator, must be different from above shortlink_shortlink_validator
    public static string shortlink_homepath = "http://url9.pro"; // please insert shortlink home path with http:// or https:// without filename index.aspx (ex: http://url9.pro)
    
    // MSSQL credentials of live website database
    public static bool mssql_enable = false; // set true if you want to use live mssql database, else set it to false
    public static string mssql_dbhost = "null"; // please insert live database source of your mssql (dbhost)
    public static string mssql_dbname = "null"; // please insert live database name of your mssql (dbname)
    public static string mssql_username = "null"; // please insert live database username of your mssql (dbuser)
    public static string mssql_password = "null"; // please insert live database password of your mssql (dbpass)

    // MSSQL credentials of localhost database
    public static bool localdb_enable = true; // set true if you want to use local mssql database, else set it to false
    public static string localdb_dbhost = "localhost"; // please insert local database source of your mssql (dbhost)
    public static string localdb_dbname = "PreURLShortSilver"; // please insert local database name of your mssql (dbname)

    // Adsense Advertisements Ads Code Settings
    public static bool adsense_enable = true; // set it true if you want to enable your adsense advertisements
    public static string adsense_pubid = "ca-pub-8177111042456736"; // set your adsense id for your adsense responsive ads. (create: Ad units > New ad unit > Text & Display Ads > Responsive > Done)
    public static string adsense_adsid1 = "1643795295"; // set your adsense id for your adsense responsive ads. (create: Ad units > New ad unit > Text & Display Ads > Responsive > Done)
    public static string adsense_adsid2 = "6338962042"; // set your adsense id for your adsense responsive ads. (create: Ad units > New ad unit > Text & Display Ads > Responsive > Done)
    public static string adsense_adsid3 = "2230952807"; // set your adsense id for your adsense responsive ads. (create: Ad units > New ad unit > Text & Display Ads > Responsive > Done)
}