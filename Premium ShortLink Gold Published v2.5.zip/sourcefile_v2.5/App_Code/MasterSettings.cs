﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// this asp.net program is written in C#
/// this asp.net program is written by PRAVEEN SAHU
/// this asp.net program's owner is DOMAINSROCK INDIA
/// this asp.net program is copyright and reserved all rights
/// contact developer: developer.projectsupport@domainsrock.in
/// www.domainsrock.in | www.domainsrock.com | www.domainsrock.info
/// </summary>
public class MasterSettings
{
    // portal page settings (do not change anything)
    public static string PortalPage_Home = "index.aspx";
    public static string PortalPage_Login = "signin.aspx";
    public static string PortalPage_Logout = "logout.aspx";
    public static string PortalPage_AdminPanel = "adminpanel.aspx";
    public static string PortalPage_PageManager = "pagemanager.aspx";

    // portal special settings (do not change anything)
    public static string SafeLoginValidation = "domainsrock";

    // portal function settings (do not change anything)
    public static string Function_ShortLink = "ShortLink";
    public static string Function_FooterMenu = "FooterMenu";
    public static string Function_PageManager = "PageManager";
    public static string Function_ShortLinkPro = "ShortLinkPro";

    // portal normal settings (do not change anything)
    public static int VisitsCounter = 0;
    public static string Website_Version = "v2.5 Gold";
}