﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Collections.Generic;

/// <summary>
/// this asp.net program is written in C#
/// this asp.net program is written by PRAVEEN SAHU
/// this asp.net program's owner is DOMAINSROCK INDIA
/// this asp.net program is copyright and reserved all rights
/// contact developer: developer.projectsupport@domainsrock.in
/// www.domainsrock.in | www.domainsrock.com | www.domainsrock.info
/// </summary>
public class DatabaseControls
{
    // configuration for required settings
    private static string CnnLive = "Data Source=" + PortalConfiguration.mssql_dbhost + ";Initial Catalog=" + PortalConfiguration.mssql_dbname + ";Integrated Security=False;User ID=" + PortalConfiguration.mssql_username + ";Password=" + PortalConfiguration.mssql_password + ";Connect Timeout=15;Encrypt=False;Packet Size=4096";
    private static string CnnLocal = "Data Source=" + PortalConfiguration.localdb_dbhost + ";Initial Catalog=" + PortalConfiguration.localdb_dbname + ";Integrated Security=True";
    public static string DBCnSource()
    {
        string DBConnection = "null";
        if (PortalConfiguration.localdb_enable) { DBConnection = CnnLocal; }
        else if (PortalConfiguration.mssql_enable) { DBConnection = CnnLive; };
        return DBConnection;
    }
    private static SqlConnection DBCn = new SqlConnection(DBCnSource());

    // it will check that connection with database is success or error
    public static bool IsDBCnFair()
    {
        bool DBCnFair;
        try { DBCn.Open(); DBCnFair = true; }
        catch (Exception) { DBCnFair = false; }
        finally { DBCn.Close(); }
        return DBCnFair;
    }

    // it will check that requested table is available on server or not
    public static bool IsTableExist(string tblname)
    {
        bool tblexist;
        string query = "select COUNT(*) from " + tblname + "";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            cmd.ExecuteScalar();
            tblexist = true;
        }
        catch (Exception) { tblexist = false; }
        finally { DBCn.Close(); }
        return tblexist;
    }

    // this function will return current date
    public static string Date()
    {
        string cDate = DateTime.Now.Day + "." + DateTime.Now.Month + "." + DateTime.Now.Year + " " + DateTime.Now.Hour + ":" + DateTime.Now.Minute + ":" + DateTime.Now.Second;
        return cDate;
    }
    
    // this function validates that given value is contains allowed char or not
    public static bool ValidateInputValue(string inputdata)
    {
        bool valid = false;
        string[] invalid = { " ", "!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "_", "-", "+", "=", "[", "]", "{", "}", "|", ":", ";", "'", "", "<", ">", "?", "/", ",", ".", "~", "`", "₹" };
        for (int i = 0; i < inputdata.Length; i++)
        {
            for (int j = 0; j < invalid.Length; j++)
            {
                string data = inputdata.Substring(i, 1);
                if (data == invalid[j]) { valid = false; break; }
                else if (i == inputdata.Length - 1 && j == invalid.Length - 1) { valid = true; break; };
            }
        }
        return valid;
    }

    // this function validates that data exists in requested table or not
    public static bool IsDataExist(string tblname)
    {
        bool dataexist = false;
        string query = "select COUNT(*) from " + tblname + "";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            int tbldata = Convert.ToInt32(cmd.ExecuteScalar().ToString());
            if (tbldata > 0) { dataexist = true; };
        }
        catch (Exception) { dataexist = false; }
        finally { DBCn.Close(); }
        return dataexist;
    }

    // this function will generate random shortlink id
    public static string GenValue_ShortId()
    {
        string[] KEYARRAY = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "" };
        string shortlink = "";
        Random RKEY = new Random();
        string KEY0 = KEYARRAY[RKEY.Next(0, 36)].ToString();
        string KEY1 = KEYARRAY[RKEY.Next(0, 36)].ToString();
        string KEY2 = KEYARRAY[RKEY.Next(0, 36)].ToString();
        string KEY3 = KEYARRAY[RKEY.Next(0, 36)].ToString();
        string KEY4 = KEYARRAY[RKEY.Next(0, 36)].ToString();
        string KEY5 = KEYARRAY[RKEY.Next(0, 36)].ToString();
        string KEY6 = KEYARRAY[RKEY.Next(0, 36)].ToString();
        string KEY7 = KEYARRAY[RKEY.Next(0, 36)].ToString();
        string KEY8 = KEYARRAY[RKEY.Next(0, 36)].ToString();
        string KEY9 = KEYARRAY[RKEY.Next(0, 36)].ToString();
        //string KEYX = KEYARRAY[RKEY.Next(0, 36)].ToString();
        //string KEYY = KEYARRAY[RKEY.Next(0, 36)].ToString();

        // enable below line to generate 10 character shortid, else disable it
        shortlink = KEY0 + "" + KEY1 + "" + KEY2 + "" + KEY3 + "" + KEY4 + "" + KEY5 + "" + KEY6 + "" + KEY7 + "" + KEY8 + "" + KEY9;
        // enable below line to generate 12 character shortid, else disable it
        //shortlink = KEY0 + "" + KEY1 + "" + KEY2 + "" + KEY3 + "" + KEY4 + "" + KEY5 + "" + KEY6 + "" + KEY7 + "" + KEY8 + "" + KEY9 + "" + KEYX + "" + KEYY;
        return shortlink;
    }

    public static int GenMenuNewId()
    {
        int id, newid;
        string query = "select MAX(footermenu_id) from " + MasterSettings.Function_FooterMenu + "";
        try { DBCn.Open(); SqlCommand cmd = new SqlCommand(query, DBCn); id = Convert.ToInt32(cmd.ExecuteScalar().ToString()); }
        catch (Exception) { id = 0; }
        finally { DBCn.Close(); }
        newid = id + 1;
        return newid;
    }

    // this function will create new table for shortlink
    public static bool NewTable_ShortLink()
    {
        bool newtable_generated = false;
        string query = "CREATE TABLE " + MasterSettings.Function_ShortLink + " (shortlink_id varchar(15) primary key,shortlink_visits bigint NOT NULL DEFAULT '0',shortlink_regdate datetime NOT NULL,shortlink_realurl varchar(500) NOT NULL)";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            cmd.ExecuteScalar();
            newtable_generated = true;
        }
        catch (Exception) { newtable_generated = false; }
        finally { DBCn.Close(); }

        return newtable_generated;
    }

    // this function will create new table for shortlink
    public static bool NewTable_ShortLinkPro()
    {
        bool newtable_generated = false;
        string query = "CREATE TABLE " + MasterSettings.Function_ShortLinkPro + " (shortlink_id varchar(30) primary key,shortlink_visits bigint NOT NULL DEFAULT '0',shortlink_regdate datetime NOT NULL,shortlink_realurl varchar(500) NOT NULL)";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            cmd.ExecuteScalar();
            newtable_generated = true;
        }
        catch (Exception) { newtable_generated = false; }
        finally { DBCn.Close(); }

        return newtable_generated;
    }

    // this function will create new table for shortlink
    public static bool NewTable_PageManager()
    {
        bool newtable_generated = false;
        string query = "CREATE TABLE " + MasterSettings.Function_PageManager + " (page_id varchar(50) primary key,page_views bigint not null DEFAULT '0',page_name varchar(50) not null DEFAULT 'New Page',page_title varchar(100) not null DEFAULT 'Untitled',page_date datetime not null DEFAULT '01.01.2000 00:00:00 AM',page_update datetime not null DEFAULT '01.01.2000 00:00:00AM',page_content varchar(max) not null DEFAULT 'Page Content')";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            cmd.ExecuteScalar();
            newtable_generated = true;
        }
        catch (Exception) { newtable_generated = false; }
        finally { DBCn.Close(); }

        return newtable_generated;
    }

    // this function will create new table for footermenu
    public static bool NewTable_FooterMenu()
    {
        bool newtable_generated = false;
        string query = "CREATE TABLE " + MasterSettings.Function_FooterMenu + " (footermenu_id int primary key,footermenu_panel int not null,footermenu_title varchar(50) not null DEFAULT 'Footer Menu Link',footermenu_navigationurl varchar(256) not null DEFAULT '#')";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            cmd.ExecuteScalar();
            newtable_generated = true;
        }
        catch (Exception) { newtable_generated = false; }
        finally { DBCn.Close(); }

        return newtable_generated;
    }

    // this function will validate id value from shortlink
    public static bool Validate_ShortLink_ShortId(string id)
    {
        bool validated = false;
        string query = "SELECT shortlink_id from " + MasterSettings.Function_ShortLink + " where shortlink_id='" + id + "'";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            if (id == cmd.ExecuteScalar().ToString()) { validated = true; } else { validated = false; }
        }
        catch (Exception) { }
        finally { DBCn.Close(); }
        return validated;
    }

    // this function will validate id value from shortlink
    public static bool Validate_ShortLinkPro_ShortId(string id)
    {
        bool validated = false;
        string query = "SELECT shortlink_id from " + MasterSettings.Function_ShortLinkPro + " where shortlink_id='" + id + "'";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            if (id == cmd.ExecuteScalar().ToString()) { validated = true; } else { validated = false; }
        }
        catch (Exception) { }
        finally { DBCn.Close(); }
        return validated;
    }

    // this function will validate id value from pagemanager
    public static bool Validate_PageManager_PageId(string id)
    {
        bool validated = false;
        string query = "SELECT page_id from " + MasterSettings.Function_PageManager + " where page_id='" + id + "'";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            if (id == cmd.ExecuteScalar().ToString()) { validated = true; } else { validated = false; }
        }
        catch (Exception) { }
        finally { DBCn.Close(); }
        return validated;
    }

    // this function will return fresh shortlink id
    private static string GenValueFresh_ShortLink_ShortId()
    {
        string fsid = GenValue_ShortId();
        while (Validate_ShortLink_ShortId(fsid)) { fsid = GenValue_ShortId(); };
        return fsid;
    }

    // this function will return fresh shortlink id
    private static string GenValueFresh_ShortLinkPro_ShortId()
    {
        string fsid = GenValue_ShortId();
        while (Validate_ShortLinkPro_ShortId(fsid)) { fsid = GenValue_ShortId(); };
        return fsid;
    }

    // this function will insert values in shortlink
    public static string InsertValues_ShortLink(string realurl)
    {
        string insertvalues_shortlinkid = GenValueFresh_ShortLink_ShortId();
        string query = "INSERT INTO " + MasterSettings.Function_ShortLink + " VALUES ('" + insertvalues_shortlinkid + "','0','" + Date() + "','" + realurl + "')";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            cmd.ExecuteNonQuery();
        }
        catch (Exception) { }
        finally { DBCn.Close(); }

        return insertvalues_shortlinkid;
    }

    // this function will insert values in shortlink
    public static string InsertValues_ShortLinkPro(string realurl)
    {
        string insertvalues_shortlinkid = GenValueFresh_ShortLinkPro_ShortId();
        string query = "INSERT INTO " + MasterSettings.Function_ShortLinkPro + " VALUES ('" + insertvalues_shortlinkid + "','0','" + Date() + "','" + realurl + "')";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            cmd.ExecuteNonQuery();
        }
        catch (Exception) { }
        finally { DBCn.Close(); }

        return insertvalues_shortlinkid;
    }

    // this function will insert values in shortlink
    public static bool InsertValues_ShortLinkProManual(string shortid, string realurl)
    {
        bool isInserted = false;
        string query = "INSERT INTO " + MasterSettings.Function_ShortLinkPro + " VALUES ('" + shortid + "','0','" + Date() + "','" + realurl + "')";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            cmd.ExecuteNonQuery();
            isInserted = true;
        }
        catch (Exception) { }
        finally { DBCn.Close(); }

        return isInserted;
    }

    // this function will insert values in shortlink
    public static bool InsertValues_FooterMenu(string menupanel, string linkname, string linkvisiturl)
    {
        bool insertvalues = false;
        int menuid = GenMenuNewId();
        string query = "insert into " + MasterSettings.Function_FooterMenu + " values (" + menuid + "," + menupanel + ",'" + linkname + "','" + linkvisiturl + "')";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            cmd.ExecuteNonQuery();
            insertvalues = true;
        }
        catch (Exception) { }
        finally { DBCn.Close(); }

        return insertvalues;
    }

    // this function will insert values in pagemanager
    public static bool InsertValues_PageManager(string pageid,string pagename, string pagetitle,string pagecontent)
    {
        bool insertvalues = false;
        string query = "insert into " + MasterSettings.Function_PageManager + " values ('" + pageid + "',0,'" + pagename + "','" + pagetitle + "','" + Date() + "','" + Date() + "','" + pagecontent + "')";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            cmd.ExecuteNonQuery();
            insertvalues = true;
        }
        catch (Exception) { }
        finally { DBCn.Close(); }

        return insertvalues;
    }

    // this function will insert values in pagemanager
    public static bool UpdateValue_PageManager(string opageid, string npageid, string pagename, string pagetitle, string pagecontent)
    {
        bool updatedvalues = false;
        string query = "update " + MasterSettings.Function_PageManager + " set page_id='" + npageid + "',page_name='" + pagename + "',page_title='" + pagetitle + "',page_update='" + Date() + "',page_content='" + pagecontent + "' where page_id='" + opageid + "'";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            cmd.ExecuteNonQuery();
            updatedvalues = true;
        }
        catch (Exception) { updatedvalues = false; }
        finally { DBCn.Close(); }

        return updatedvalues;
    }

    // this function will insert values in pagemanager
    public static bool UpdateValue_ShortLinkPro(string oldshortcode, string newshortcode, string visiturl)
    {
        bool updatedvalues = false;
        string query = "update " + MasterSettings.Function_ShortLinkPro + " set shortlink_id='" + newshortcode + "',shortlink_realurl='" + visiturl + "' where shortlink_id='" + oldshortcode + "'";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            cmd.ExecuteNonQuery();
            updatedvalues = true;
        }
        catch (Exception) { updatedvalues = false; }
        finally { DBCn.Close(); }

        return updatedvalues;
    }

    // this function will insert values in pagemanager
    public static bool UpdateValue_FooterMenu(int menuid, string linkname, string visiturl)
    {
        bool updatedvalues = false;
        string query = "update " + MasterSettings.Function_FooterMenu + " set footermenu_title='" + linkname + "',footermenu_navigationurl='" + visiturl + "' where footermenu_id='" + menuid + "'";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            cmd.ExecuteNonQuery();
            updatedvalues = true;
        }
        catch (Exception) { updatedvalues = false; }
        finally { DBCn.Close(); }

        return updatedvalues;
    }

    // this function will insert values in pagemanager
    public static bool DeleteValue_ShortLinkPro(string shortcode)
    {
        bool deletedvalues = false;
        string query = "delete " + MasterSettings.Function_ShortLinkPro + " where shortlink_id='" + shortcode + "'";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            cmd.ExecuteNonQuery();
            deletedvalues = true;
        }
        catch (Exception) { deletedvalues = false; }
        finally { DBCn.Close(); }

        return deletedvalues;
    }

    // this function will insert values in pagemanager
    public static bool DeleteValue_FooterMenu(int menuid)
    {
        bool deletedvalues = false;
        string query = "delete " + MasterSettings.Function_FooterMenu + " where footermenu_id='" + menuid + "'";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            cmd.ExecuteNonQuery();
            deletedvalues = true;
        }
        catch (Exception) { deletedvalues = false; }
        finally { DBCn.Close(); }

        return deletedvalues;
    }

    // this function will return realurl value from shortlink
    public static string GetValues_ShortLink_RealURL(string id)
    {
        string result = "null";
        string query = "SELECT shortlink_realurl from " + MasterSettings.Function_ShortLink + " where shortlink_id='" + id + "'";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            result = cmd.ExecuteScalar().ToString();
        }
        catch (Exception) { result = "null"; }
        finally { DBCn.Close(); }
        return result;
    }

    // this function will return realurl value from shortlink
    public static string GetValues_ShortLinkPro_RealURL(string id)
    {
        string result = "null";
        string query = "SELECT shortlink_realurl from " + MasterSettings.Function_ShortLinkPro + " where shortlink_id='" + id + "'";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            result = cmd.ExecuteScalar().ToString();
        }
        catch (Exception) { result = "null"; }
        finally { DBCn.Close(); }
        return result;
    }

    // this function will return pagecontent value from pagemanager
    public static string GetValues_PageManager_PageContent(string id)
    {
        string result = "null";
        string query = "SELECT page_content from " + MasterSettings.Function_PageManager + " where page_id='" + id + "'";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            result = cmd.ExecuteScalar().ToString();
        }
        catch (Exception) { result = "null"; }
        finally { DBCn.Close(); }
        return result;
    }

    // this function will return pagetitle value from pagemanager
    public static string GetValues_PageManager_PageTitle(string id)
    {
        string result = "null";
        string query = "SELECT page_title from " + MasterSettings.Function_PageManager + " where page_id='" + id + "'";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            result = cmd.ExecuteScalar().ToString();
        }
        catch (Exception) { result = "null"; }
        finally { DBCn.Close(); }
        return result;
    }

    // this function will return menutitle value from footermenu
    public static string GetValues_FooterMenu_MenuTitle(int fid)
    {
        string result = "null";
        string query = "SELECT footermenu_title from " + MasterSettings.Function_FooterMenu + " where footermenu_id='" + fid + "'";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            result = cmd.ExecuteScalar().ToString();
        }
        catch (Exception) { result = "null"; }
        finally { DBCn.Close(); }
        return result;
    }

    // this function will return menuURL value from footermenu
    public static string GetValues_FooterMenu_MenuURL(int fid)
    {
        string result = "null";
        string query = "SELECT footermenu_navigationurl from " + MasterSettings.Function_FooterMenu + " where footermenu_id=" + fid + "";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            result = cmd.ExecuteScalar().ToString();
        }
        catch (Exception) { result = "null"; }
        finally { DBCn.Close(); }
        return result;
    }

    // this function will return page views value from pagemanager
    public static int GetValues_PageManager_PageViews(string id)
    {
        int count = 0;
        string query = "SELECT page_views from " + MasterSettings.Function_PageManager + " where page_id='" + id + "'";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            count = Convert.ToInt32(cmd.ExecuteScalar().ToString());
        }
        catch (Exception) { count = 0; }
        finally { DBCn.Close(); }
        return count;
    }    

    // this function will update data for footermenu
    public static bool Update_FooterMenu(int id, string title, string url)
    {
        bool DataUpdated = false; if (title == "" || title == null) { title = "null"; }; if (url == "" || url == null) { url = "#"; };
        string query = "update " + MasterSettings.Function_FooterMenu + " set footermenu_title='" + title + "',footermenu_navigationurl='" + url + "' where footermenu_id='" + id + "'";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            cmd.ExecuteNonQuery();
            DataUpdated = true;
        }
        catch (Exception) { DataUpdated = false; }
        finally { DBCn.Close(); }

        return DataUpdated;
    }

    // this function will update data for pagemanage
    public static bool Update_PageManager_PageViews(string id)
    {
        bool DataUpdated = false;
        string query = "update " + MasterSettings.Function_PageManager + " set page_views=page_views+1 where page_id='" + id + "'";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            cmd.ExecuteNonQuery();
            DataUpdated = true;
        }
        catch (Exception) { DataUpdated = false; }
        finally { DBCn.Close(); }

        return DataUpdated;
    }

    // this function counts total entry for requested table
    public static int CountData_ShortLink()
    {
        int count = 0;
        string query = "select COUNT(*) from " + MasterSettings.Function_ShortLink + "";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            count = Convert.ToInt32(cmd.ExecuteScalar().ToString());
            if (count < 1) { count = 0; };
        }
        catch (Exception) { count = 0; }
        finally { DBCn.Close(); }
        return count;
    }

    // this function counts total entry for requested table
    public static int CountData_FooterMenu()
    {
        int count = 0;
        string query = "select COUNT(*) from " + MasterSettings.Function_FooterMenu + "";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            count = Convert.ToInt32(cmd.ExecuteScalar().ToString());
            if (count < 1) { count = 0; };
        }
        catch (Exception) { count = 0; }
        finally { DBCn.Close(); }
        return count;
    }

    // this function counts total entry for requested table
    public static int CountData_ShortLinkPro()
    {
        int count = 0;
        string query = "select COUNT(*) from " + MasterSettings.Function_ShortLinkPro + "";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            count = Convert.ToInt32(cmd.ExecuteScalar().ToString());
            if (count < 1) { count = 0; };
        }
        catch (Exception) { count = 0; }
        finally { DBCn.Close(); }
        return count;
    }       

    // this function counts total value for requested table
    public static int GetValues_TotalCountData_ShortLink_Visits()
    {
        int count = 0;
        string query = "select shortlink_visits from " + MasterSettings.Function_ShortLink + "";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read()) { count = count + Convert.ToInt32(dr[0].ToString()); }
        }
        catch (Exception) { count = 0; }
        finally { DBCn.Close(); }
        return count;
    }

    // this function counts total value for requested table
    public static int GetValues_TotalCountData_ShortLinkPro_Visits()
    {
        int count = 0;
        string query = "select shortlink_visits from " + MasterSettings.Function_ShortLinkPro + "";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read()) { count = count + Convert.ToInt32(dr[0].ToString()); }
        }
        catch (Exception) { count = 0; }
        finally { DBCn.Close(); }
        return count;
    }

    // this function gets value for requested table
    public static int GetValue_ShortLink_Visits(string id)
    {
        int count = 0;
        string query = "select shortlink_visits from " + MasterSettings.Function_ShortLink + " where shortlink_id='" + id + "'";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            count = Convert.ToInt32(cmd.ExecuteReader().ToString());
        }
        catch (Exception) { count = 0; }
        finally { DBCn.Close(); }
        return count;
    }

    // this function gets value for requested table
    public static int GetValue_ShortLinkPro_Visits(string id)
    {
        int count = 0;
        string query = "select shortlink_visits from " + MasterSettings.Function_ShortLinkPro + " where shortlink_id='" + id + "'";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            count = Convert.ToInt32(cmd.ExecuteReader().ToString());
        }
        catch (Exception) { count = 0; }
        finally { DBCn.Close(); }
        return count;
    }

    // this function counts total value for requested table
    public static void UpdateValue_ShortLink_Visits(string id)
    {
        int count = GetValue_ShortLink_Visits(id) + 1;
        string query = "update " + MasterSettings.Function_ShortLink + " set shortlink_visits=shortlink_visits+1 where shortlink_id='" + id + "'";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            cmd.ExecuteNonQuery();
        }
        catch (Exception) { count = 0; }
        finally { DBCn.Close(); }
    }

    // this function counts total value for requested table
    public static void UpdateValue_ShortLinkPro_Visits(string id)
    {
        int count = GetValue_ShortLinkPro_Visits(id) + 1;
        string query = "update " + MasterSettings.Function_ShortLinkPro + " set shortlink_visits=shortlink_visits+1 where shortlink_id='" + id + "'";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            cmd.ExecuteNonQuery();
        }
        catch (Exception) { count = 0; }
        finally { DBCn.Close(); }
    }    

    // this function will perform delete action for pagemanager
    public static bool DeleteFunction_PageManager_DeleteSingleRecord(string pageid)
    {
        bool deleted = false;
        string query = "delete from " + MasterSettings.Function_PageManager + " where page_id='" + pageid + "'";
        try
        {
            DBCn.Open();
            SqlCommand cmd = new SqlCommand(query, DBCn);
            cmd.ExecuteNonQuery();
            deleted = true;
        }
        catch (Exception) { }
        finally { DBCn.Close(); }
        return deleted;
    }
}