﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

/// <summary>
/// this asp.net program is written in C#
/// this asp.net program is written by PRAVEEN SAHU
/// this asp.net program's owner is DOMAINSROCK INDIA
/// this asp.net program is copyright and reserved all rights
/// contact developer: developer.projectsupport@domainsrock.in
/// www.domainsrock.in | www.domainsrock.com | www.domainsrock.info
/// </summary>
public partial class managemenu : System.Web.UI.Page
{
    string AuthUsername = "null", AuthPassword = "null", DBSource;
    bool EnablePageAccess = false; string action; int reqpage, menuid;
    protected void Page_Load(object sender, EventArgs e)
    {
        DBSource = DatabaseControls.DBCnSource();
        SqlConnection SQLCn = new SqlConnection(DBSource);

        try { reqpage = Convert.ToInt32(Request.QueryString["page"].ToString()); }
        catch (Exception) { reqpage = 1; }
        try { action = Request.QueryString["action"].ToString(); }
        catch (Exception) { action = "null"; }
        try { menuid = Convert.ToInt32(Request.QueryString["menuid"].ToString()); }
        catch (Exception) { menuid = 0; }

        // this function will check that user is logged-in or not
        HttpCookieCollection Col = Request.Cookies;
        if (Col != null)
        {
            HttpCookie CoLogin = null;
            for (int c = 0; c < Col.Count; c++)
            {
                CoLogin = Col[c];
                if (CoLogin.Name == MasterSettings.SafeLoginValidation + ".Username") { AuthUsername = PortalControls.DecodePasswordFromBase64(CoLogin.Value.ToString()); };
                if (CoLogin.Name == MasterSettings.SafeLoginValidation + ".Password") { AuthPassword = PortalControls.DecodePasswordFromBase64(CoLogin.Value.ToString()); };
                if (AuthUsername != "null" && AuthPassword != "null")
                {
                    if (AuthUsername == PortalConfiguration.admin_username && AuthPassword == PortalConfiguration.admin_password) { EnablePageAccess = true; break; };
                    break;
                }
                else if (c == Col.Count - 1) { Response.Redirect(MasterSettings.PortalPage_Home); break; }
            }
        };

        if (EnablePageAccess)
        {
            if (DatabaseControls.IsTableExist(MasterSettings.Function_FooterMenu))
            {
                if (action == "addnew" || action == "edit" || action == "delete")
                {

                    if (action == "addnew")
                    {
                        menufunction_addmenu.Visible = true; menufunction_default.Visible = menufunction_deletemenu.Visible = menufunction_editmenu.Visible = false;
                    }
                    else if (action == "edit")
                    {
                        menufunction_editmenu.Visible = true; menufunction_default.Visible = menufunction_deletemenu.Visible = menufunction_addmenu.Visible = false;
                        if (!IsPostBack) { editmenu_linkname.Text = DatabaseControls.GetValues_FooterMenu_MenuTitle(menuid); editmenu_visiturl.Text = DatabaseControls.GetValues_FooterMenu_MenuURL(menuid); }
                    }
                    else if (action == "delete")
                    {
                        menufunction_deletemenu.Visible = true; menufunction_default.Visible = menufunction_editmenu.Visible = menufunction_addmenu.Visible = false;
                        if (!IsPostBack) { delete_linkname.Text = DatabaseControls.GetValues_FooterMenu_MenuTitle(menuid); delete_visiturl.Text = DatabaseControls.GetValues_FooterMenu_MenuURL(menuid); golink_editmenu.NavigateUrl = "?action=edit&menuid=" + menuid + ""; }
                    };
                }
                else { menufunction_default.Visible = true; div_error.Visible = div_information.Visible = div_success.Visible = div_warning.Visible = false; }

                // this function for pagination - start
                int countdata = DatabaseControls.CountData_FooterMenu();
                int countpage = countdata / 10;
                int countlpagedata = countdata % 10;
                int totalpage = countpage;
                if (countlpagedata > 0) { totalpage = countpage + 1; };

                int viewpage = reqpage;
                int nextpage = viewpage + 1;
                int prevpage = viewpage - 1;
                if (totalpage == 1) { pagination.Visible = pagination_first.Enabled = pagination_last.Enabled = pagination_next.Enabled = pagination_previous.Enabled = false; };
                // this function for pagination - end

                try
                {
                    string SQLQuery = "SELECT footermenu_id,footermenu_panel,footermenu_title,footermenu_navigationurl from " + MasterSettings.Function_FooterMenu + " order by footermenu_id desc";
                    SQLCn.Open();
                    SqlCommand SQLCmd = new SqlCommand(SQLQuery, SQLCn);
                    SqlDataReader SQLDR = SQLCmd.ExecuteReader();

                    // table header elements
                    TableHeaderRow THR = new TableHeaderRow();
                    table_function_default.Rows.Add(THR);
                    TableHeaderCell THC1 = new TableHeaderCell();
                    THC1.Text = "Panel";
                    THR.Cells.Add(THC1);
                    TableHeaderCell THC2 = new TableHeaderCell();
                    THC2.Text = "Title";
                    THR.Cells.Add(THC2);
                    TableHeaderCell THC3 = new TableHeaderCell();
                    THC3.Text = "VisitURL";
                    THR.Cells.Add(THC3);
                    TableHeaderCell THC4 = new TableHeaderCell();
                    THC4.Text = "Action";
                    THR.Cells.Add(THC4);


                    // below function will display list
                    int lastcount = viewpage * 10;
                    int firstcount = lastcount - 10;

                    if (viewpage == 1)
                    {
                        int count = 0;
                        while (SQLDR.Read())
                        {
                            if (count < 10)
                            {
                                // table content elements
                                TableRow TR = new TableRow();
                                table_function_default.Rows.Add(TR);
                                TableCell TC1 = new TableCell();
                                TC1.Text = SQLDR["footermenu_panel"].ToString();
                                TR.Cells.Add(TC1);
                                TableCell TC2 = new TableCell();
                                TC2.Text = SQLDR["footermenu_title"].ToString();
                                TR.Cells.Add(TC2);
                                TableCell TC3 = new TableCell();
                                TC3.Text = SQLDR["footermenu_navigationurl"].ToString();
                                TR.Cells.Add(TC3);

                                string btnvisit = "<a href='" + SQLDR["footermenu_navigationurl"].ToString() + "' class='btn btn-xs btn-primary'><font color='white'>Visit</font></a>";
                                string btnedit = "<a href='managemenu.aspx?action=edit&menuid=" + SQLDR["footermenu_id"].ToString() + "' class='btn btn-xs btn-success'><font color='white'>Edit</font></a>";
                                string btndelete = "<a href='managemenu.aspx?action=delete&menuid=" + SQLDR["footermenu_id"].ToString() + "' class='btn btn-xs btn-danger'><font color='white'>Delete</font></a>";

                                TableCell TC4 = new TableCell();
                                TC4.Text = btnvisit + " " + btnedit + " " + btndelete;
                                TR.Cells.Add(TC4);
                                count = count + 1;
                            }
                            else { break; }
                        }
                        pagination_first.Enabled = pagination_previous.Enabled = false;
                        pagination_next.NavigateUrl = "?page=" + nextpage + "";
                        pagination_last.NavigateUrl = "?page=" + totalpage + "";
                    }
                    else
                    {
                        int count = 0;
                        while (SQLDR.Read())
                        {
                            if (count < firstcount) { count = count + 1; }
                            else if (count < lastcount)
                            {

                                // table content elements
                                TableRow TR = new TableRow();
                                table_function_default.Rows.Add(TR);
                                TableCell TC1 = new TableCell();
                                TC1.Text = SQLDR["footermenu_panel"].ToString();
                                TR.Cells.Add(TC1);
                                TableCell TC2 = new TableCell();
                                TC2.Text = SQLDR["footermenu_title"].ToString();
                                TR.Cells.Add(TC2);
                                TableCell TC3 = new TableCell();
                                TC3.Text = SQLDR["footermenu_navigationurl"].ToString();
                                TR.Cells.Add(TC3);

                                string btnvisit = "<a href='" + PortalConfiguration.shortlink_homepath + "?" + PortalConfiguration.shortlinkpro_validator + "=" + SQLDR["footermenu_id"].ToString() + "' class='btn btn-xs btn-primary'><font color='white'>Visit</font></a>";
                                string btnedit = "<a href='managemenu.aspx?action=edit&menuid=" + SQLDR["footermenu_id"].ToString() + "' class='btn btn-xs btn-success'><font color='white'>Edit</font></a>";
                                string btndelete = "<a href='managemenu.aspx?action=delete&menuid=" + SQLDR["footermenu_id"].ToString() + "' class='btn btn-xs btn-danger'><font color='white'>Delete</font></a>";

                                TableCell TC4 = new TableCell();
                                TC4.Text = btnvisit + " " + btnedit + " " + btndelete;
                                TR.Cells.Add(TC4);
                                count = count + 1;
                            }
                            else { break; }
                        }
                        pagination_previous.NavigateUrl = "?page=" + prevpage + "";
                        pagination_next.NavigateUrl = "?page=" + nextpage + "";
                        pagination_last.NavigateUrl = "?page=" + totalpage + "";
                        if (viewpage == totalpage) { pagination_next.Enabled = pagination_last.Enabled = false; };
                    }
                }
                catch (Exception) { }
                finally { SQLCn.Close(); }
            }
            else { div_error.Visible = true; label_error.Text = "FooterMenu Function is not Installed <a href='" + MasterSettings.PortalPage_AdminPanel + "'>Click Here to Install this Function</a>"; div_information.Visible = div_success.Visible = div_warning.Visible = menufunction_default.Visible = false; }
        };
    }
    protected void button_addmenu_Click(object sender, EventArgs e)
    {
        string panel = input_menupanel.SelectedValue;
        string linkname = input_linkname.Text;
        string linkvisiturl = input_visiturl.Text;
        if (linkname.Length > 0 && linkvisiturl.Length > 0)
        {
            if (DatabaseControls.InsertValues_FooterMenu(panel, linkname, linkvisiturl)) { div_success.Visible = menufunction_default.Visible = true; label_success.Text = "New Link Added Successfully to Footer Menu..."; menufunction_addmenu.Visible = div_warning.Visible = div_information.Visible = div_error.Visible = false; }
            else { div_error.Visible = true; label_error.Text = "Unable to Proceed due to Some Technical Issue"; div_information.Visible = div_success.Visible = div_warning.Visible = false; }
        }
        else { div_error.Visible = true; label_error.Text = "Unable to Proceed due to Invalid Request"; div_information.Visible = div_success.Visible = div_warning.Visible = false; }
    }
    protected void button_updatemenu_Click(object sender, EventArgs e)
    {
        if (DatabaseControls.UpdateValue_FooterMenu(menuid, editmenu_linkname.Text, editmenu_visiturl.Text)) { div_success.Visible = menufunction_default.Visible = true; label_success.Text = "Link Updated Successfully of Footer Menu..."; menufunction_deletemenu.Visible = menufunction_editmenu.Visible = menufunction_addmenu.Visible = div_warning.Visible = div_information.Visible = div_error.Visible = false; }
        else { div_error.Visible = true; label_error.Text = "Unable to Proceed due to Some Technical Issue"; div_information.Visible = div_success.Visible = div_warning.Visible = false; }
    }
    protected void button_deletemenu_Click(object sender, EventArgs e)
    {
        if (DatabaseControls.DeleteValue_FooterMenu(menuid)) { div_success.Visible = menufunction_default.Visible = true; label_success.Text = "Link Deleted Successfully of Footer Menu..."; menufunction_deletemenu.Visible = menufunction_editmenu.Visible = menufunction_addmenu.Visible = div_warning.Visible = div_information.Visible = div_error.Visible = false; }
        else { div_error.Visible = true; label_error.Text = "Unable to Proceed due to Some Technical Issue"; div_information.Visible = div_success.Visible = div_warning.Visible = false; }
    }
}