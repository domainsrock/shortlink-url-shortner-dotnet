﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

/// <summary>
/// this asp.net program is written in C#
/// this asp.net program is written by PRAVEEN SAHU
/// this asp.net program's owner is DOMAINSROCK INDIA
/// this asp.net program is copyright and reserved all rights
/// contact developer: developer.projectsupport@domainsrock.in
/// www.domainsrock.in | www.domainsrock.com | www.domainsrock.info
/// </summary>
public partial class signin : System.Web.UI.Page
{
    string Username, Password, AuthUsername = "null", AuthPassword = "null";
    protected void Page_Load(object sender, EventArgs e)
    {
        HttpCookieCollection Col2 = Request.Cookies;
        if (Col2 != null)
        {
            HttpCookie CoLogin = null;
            for (int c = 0; c < Col2.Count; c++)
            {
                CoLogin = Col2[c];
                if (CoLogin.Name == MasterSettings.SafeLoginValidation + ".Username") { AuthUsername = PortalControls.DecodePasswordFromBase64(CoLogin.Value.ToString()); };
                if (CoLogin.Name == MasterSettings.SafeLoginValidation + ".Password") { AuthPassword = PortalControls.DecodePasswordFromBase64(CoLogin.Value.ToString()); };
                if (AuthUsername != "null" && AuthPassword != "null")
                {
                    if (AuthUsername == PortalConfiguration.admin_username && AuthPassword == PortalConfiguration.admin_password) { Response.Redirect("index.aspx"); }
                    else { Response.Redirect(MasterSettings.PortalPage_Logout); }
                    break;
                }
                else if (c == Col2.Count - 1)
                {
                    div_warning.Visible = true;
                    label_warning.Text = "You Must Login First into Your Account for Full Authentication...";
                    button_signin.Enabled = true;
                    break;
                }
            }
        }
        else
        {
            div_error.Visible = true;
            label_error.Text = "You Must Login First into Your Account for Full Authentication...";
        }
    }

    protected void button_signin_Click(object sender, EventArgs e)
    {
        Username = input_username.Text.ToLower();
        Password = input_password.Text;
        string SafeLogin, SafePswrd;

        if (Username == PortalConfiguration.admin_username)
        {
            if (Username == PortalConfiguration.admin_username && Password == PortalConfiguration.admin_password)
            {
                // creating safe cookies for username
                SafeLogin = PortalControls.EncodePasswordToBase64(Username);
                HttpCookie SafeUsername = new HttpCookie(MasterSettings.SafeLoginValidation + ".Username", SafeLogin);
                SafeUsername.Expires = DateTime.Now.AddDays(10);
                Response.Cookies.Add(SafeUsername);

                // creating safe cookies for username
                SafePswrd = PortalControls.EncodePasswordToBase64(Password);
                HttpCookie SafePassword = new HttpCookie(MasterSettings.SafeLoginValidation + ".Password", SafePswrd);
                SafePassword.Expires = DateTime.Now.AddDays(10);
                Response.Cookies.Add(SafePassword);

                // this function will redirects users to home page of wapsite after successfull login
                Response.Redirect(MasterSettings.PortalPage_Home);
            }
            else { div_error.Visible = true; label_error.Text = "Password is Incorrect..."; }
        }
        else { div_error.Visible = true; label_error.Text = "Username is Incorrect..."; }
    }
}