﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

/// <summary>
/// this asp.net program is written in C#
/// this asp.net program is written by PRAVEEN SAHU
/// this asp.net program's owner is DOMAINSROCK INDIA
/// this asp.net program is copyright and reserved all rights
/// contact developer: developer.projectsupport@domainsrock.in
/// www.domainsrock.in | www.domainsrock.com | www.domainsrock.info
/// </summary>
public partial class maindesign : System.Web.UI.MasterPage
{
    string MasterAuthUsername = "null", MasterAuthPassword = "null";
    bool EnableAdminFunction = false; string DBSource;
    string[] FT, FU;
    protected void Page_Load(object sender, EventArgs e)
    {
        MasterSettings.VisitsCounter = MasterSettings.VisitsCounter + 1;
        DBSource = DatabaseControls.DBCnSource();
        SqlConnection SQLCn = new SqlConnection(DBSource);

        // this function will initialtes values to all labels
        portal_head.Title = PortalConfiguration.website_title;
        label_portalname.Text = PortalConfiguration.website_name;
        label_totalvisits.Text = MasterSettings.VisitsCounter.ToString();
        label_websiteversion.Text = MasterSettings.Website_Version;

        label_freeshortedlinks.Text = DatabaseControls.CountData_ShortLink().ToString();
        label_proshortedlinks.Text = DatabaseControls.CountData_ShortLinkPro().ToString();
        label_freelinkvisits.Text = DatabaseControls.GetValues_TotalCountData_ShortLink_Visits().ToString();
        label_prolinkvisits.Text = DatabaseControls.GetValues_TotalCountData_ShortLinkPro_Visits().ToString();

        if (PortalConfiguration.adsense_enable)
        {
            adsense_advertisement1.Visible = adsense_advertisement2.Visible = adsense_advertisement3.Visible = true;
            adsense_advertisement1_adscode.Text = "<script async src='//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js'></script><ins class='adsbygoogle' style='display:block' data-ad-client='" + PortalConfiguration.adsense_pubid + "' data-ad-slot='" + PortalConfiguration.adsense_adsid1 + "' data-ad-format='auto'></ins><script>(adsbygoogle = window.adsbygoogle || []).push({});</script>";
            adsense_advertisement2_adscode.Text = "<script async src='//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js'></script><ins class='adsbygoogle' style='display:block' data-ad-client='" + PortalConfiguration.adsense_pubid + "' data-ad-slot='" + PortalConfiguration.adsense_adsid2 + "' data-ad-format='auto'></ins><script>(adsbygoogle = window.adsbygoogle || []).push({});</script>";
            adsense_advertisement3_adscode.Text = "<script async src='//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js'></script><ins class='adsbygoogle' style='display:block' data-ad-client='" + PortalConfiguration.adsense_pubid + "' data-ad-slot='" + PortalConfiguration.adsense_adsid3 + "' data-ad-format='auto'></ins><script>(adsbygoogle = window.adsbygoogle || []).push({});</script>";
        }
        else { adsense_advertisement1.Visible = adsense_advertisement2.Visible = adsense_advertisement3.Visible = false; }

        imagelogo.ImageUrl = PortalConfiguration.website_logo;
        label_copyrights.Text = "Copyrights &copy; " + DateTime.Now.Year + " - " + PortalConfiguration.website_domain + " | All Rights Reserved.";

        // this function will check that user is logged-in or not
        HttpCookieCollection Col = Request.Cookies;
        if (Col != null)
        {
            HttpCookie CoLogin = null;
            for (int c = 0; c < Col.Count; c++)
            {
                CoLogin = Col[c];
                if (CoLogin.Name == MasterSettings.SafeLoginValidation + ".Username") { MasterAuthUsername = PortalControls.DecodePasswordFromBase64(CoLogin.Value.ToString()); };
                if (CoLogin.Name == MasterSettings.SafeLoginValidation + ".Password") { MasterAuthPassword = PortalControls.DecodePasswordFromBase64(CoLogin.Value.ToString()); };
                if (MasterAuthUsername != "null" && MasterAuthPassword != "null")
                {
                    if (MasterAuthUsername == PortalConfiguration.admin_username && MasterAuthPassword == PortalConfiguration.admin_password)
                    {
                        EnableAdminFunction = true;
                        hmlink_link7.Text = MasterAuthUsername + " <font color='red'>(logout)</font>";
                        hmlink_link7.NavigateUrl = MasterSettings.PortalPage_Logout;
                        break;
                    };
                    break;
                }
                else if (c == Col.Count - 1) { break; }
            }
        };

        if (EnableAdminFunction)
        {
            hmlink_link3.Visible = hmlink_link4.Visible = hmlink_link5.Visible = hmlink_link6.Visible = true;
            if (DatabaseControls.IsDBCnFair())
            {
                if (DatabaseControls.IsTableExist(MasterSettings.Function_ShortLink))
                {
                }
                else { div_error.Visible = true; label_error.Text = "ShortLink Function is not Installed <a href='adminpanel.aspx'>Click Here to Install this Function</a>"; }
            }
            else { div_error.Visible = true; label_error.Text = "Database Connection is not Working! Please Setup Database Configuration"; }
        }
        else
        {

        }


        // function for footer menu panel 1
        try
        {
            string SQLQuery = "SELECT footermenu_title,footermenu_navigationurl from " + MasterSettings.Function_FooterMenu + " where footermenu_panel='1' order by footermenu_id asc";
            SQLCn.Open();
            SqlCommand SQLCmd = new SqlCommand(SQLQuery, SQLCn);
            SqlDataReader SQLDR = SQLCmd.ExecuteReader();
            int count = 0;
            while (SQLDR.Read())
            {
                if (count < 10)
                {
                    // table content elements
                    TableRow TR = new TableRow();
                    footermenu_panel1.Rows.Add(TR);
                    string fmenulink = "<a href='" + SQLDR["footermenu_navigationurl"].ToString() + "' class='list-group-item' style='background-color: transparent; border: none; font-size: 14px; color: #BFE6F2; border-bottom: 1px solid #AFC7FA'><font color='white'>" + SQLDR["footermenu_title"].ToString() + "</font></a>";
                    TableCell TC1 = new TableCell();
                    TC1.Text = fmenulink;
                    TR.Cells.Add(TC1);
                    count = count + 1;
                }
                else { break; }
            }
        }
        catch (Exception) { }
        finally { SQLCn.Close(); }

        // function for footer menu panel 2
        try
        {
            string SQLQuery = "SELECT footermenu_title,footermenu_navigationurl from " + MasterSettings.Function_FooterMenu + " where footermenu_panel='2' order by footermenu_id asc";
            SQLCn.Open();
            SqlCommand SQLCmd = new SqlCommand(SQLQuery, SQLCn);
            SqlDataReader SQLDR = SQLCmd.ExecuteReader();
            int count = 0;
            while (SQLDR.Read())
            {
                if (count < 10)
                {
                    // table content elements
                    TableRow TR = new TableRow();
                    footermenu_panel2.Rows.Add(TR);
                    string fmenulink = "<a href='" + SQLDR["footermenu_navigationurl"].ToString() + "' class='list-group-item' style='background-color: transparent; border: none; font-size: 14px; color: #BFE6F2; border-bottom: 1px solid #AFC7FA'><font color='white'>" + SQLDR["footermenu_title"].ToString() + "</font></a>";
                    TableCell TC1 = new TableCell();
                    TC1.Text = fmenulink;
                    TR.Cells.Add(TC1);
                    count = count + 1;
                }
                else { break; }
            }
        }
        catch (Exception) { }
        finally { SQLCn.Close(); }

        // function for footer menu panel 3
        try
        {
            string SQLQuery = "SELECT footermenu_title,footermenu_navigationurl from " + MasterSettings.Function_FooterMenu + " where footermenu_panel='3' order by footermenu_id asc";
            SQLCn.Open();
            SqlCommand SQLCmd = new SqlCommand(SQLQuery, SQLCn);
            SqlDataReader SQLDR = SQLCmd.ExecuteReader();
            int count = 0;
            while (SQLDR.Read())
            {
                if (count < 10)
                {
                    // table content elements
                    TableRow TR = new TableRow();
                    footermenu_panel3.Rows.Add(TR);
                    string fmenulink = "<a href='" + SQLDR["footermenu_navigationurl"].ToString() + "' class='list-group-item' style='background-color: transparent; border: none; font-size: 14px; color: #BFE6F2; border-bottom: 1px solid #AFC7FA'><font color='white'>" + SQLDR["footermenu_title"].ToString() + "</font></a>";
                    TableCell TC1 = new TableCell();
                    TC1.Text = fmenulink;
                    TR.Cells.Add(TC1);
                    count = count + 1;
                }
                else { break; }
            }
        }
        catch (Exception) { }
        finally { SQLCn.Close(); }
    }
}
