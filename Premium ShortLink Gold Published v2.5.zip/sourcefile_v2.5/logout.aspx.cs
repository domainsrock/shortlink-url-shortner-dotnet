﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

/// <summary>
/// this asp.net program is written in C#
/// this asp.net program is written by PRAVEEN SAHU
/// this asp.net program's owner is DOMAINSROCK INDIA
/// this asp.net program is copyright and reserved all rights
/// contact developer: developer.projectsupport@domainsrock.in
/// www.domainsrock.in | www.domainsrock.com | www.domainsrock.info
/// </summary>
public partial class logout : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // deleting safe cookies for username
        HttpCookie SafeUsername = new HttpCookie(MasterSettings.SafeLoginValidation + ".Username");
        SafeUsername.Expires = DateTime.Now.AddDays(-1);
        Response.Cookies.Add(SafeUsername);

        // deleting safe cookies for password
        HttpCookie SafePassword = new HttpCookie(MasterSettings.SafeLoginValidation + ".Password");
        SafePassword.Expires = DateTime.Now.AddDays(-1);
        Response.Cookies.Add(SafePassword);

        // this function will removes all the created session
        Session.RemoveAll();

        // after logout from account, redirect users to index page
        Response.Redirect(MasterSettings.PortalPage_Home);
    }
}