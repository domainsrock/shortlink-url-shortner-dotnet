﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

/// <summary>
/// this asp.net program is written in C#
/// this asp.net program is written by PRAVEEN SAHU
/// this asp.net program's owner is DOMAINSROCK INDIA
/// this asp.net program is copyright and reserved all rights
/// contact developer: developer.projectsupport@domainsrock.in
/// www.domainsrock.in | www.domainsrock.com | www.domainsrock.info
/// </summary>
public partial class pagemanager : System.Web.UI.Page
{
    string AuthUsername = "null", AuthPassword = "null", action = "null", page = "null";
    bool EnablePageAccess = false; string DBSource;
    protected void Page_Load(object sender, EventArgs e)
    {
        DBSource = DatabaseControls.DBCnSource();
        SqlConnection SQLCn = new SqlConnection(DBSource);

        if (!DatabaseControls.IsTableExist(MasterSettings.Function_PageManager)) { div_error.Visible = true; div_information.Visible = div_success.Visible = div_warning.Visible = false; label_error.Text = "PageManager Function is not Installed... <a href='" + MasterSettings.PortalPage_AdminPanel + "'>Click Here to Install this Function</a>"; };

        try { action = Request.QueryString["action"].ToString(); }
        catch (Exception) { action = "null"; }
        try { page = Request.QueryString["page"].ToString(); }
        catch (Exception) { page = "null"; }

        // this function will check that user is logged-in or not
        HttpCookieCollection Col = Request.Cookies;
        if (Col != null)
        {
            HttpCookie CoLogin = null;
            for (int c = 0; c < Col.Count; c++)
            {
                CoLogin = Col[c];
                if (CoLogin.Name == MasterSettings.SafeLoginValidation + ".Username") { AuthUsername = PortalControls.DecodePasswordFromBase64(CoLogin.Value.ToString()); };
                if (CoLogin.Name == MasterSettings.SafeLoginValidation + ".Password") { AuthPassword = PortalControls.DecodePasswordFromBase64(CoLogin.Value.ToString()); };
                if (AuthUsername != "null" && AuthPassword != "null")
                {
                    if (AuthUsername == PortalConfiguration.admin_username && AuthPassword == PortalConfiguration.admin_password) { EnablePageAccess = true; break; };
                    break;
                }
                else if (c == Col.Count - 1) { Response.Redirect(MasterSettings.PortalPage_Home); break; }
            }
        };

        // this function run when user has access to this page
        if (EnablePageAccess)
        {
            panel_pagemanager.Visible = pageaction_default.Visible = true;
            if (action == "addnew" || action == "editpage" || action == "deletepage")
            {
                if (action == "addnew")
                {
                    pageaction_addnew.Visible = panel_allowedhtml.Visible = true; pageaction_default.Visible = pageaction_editpage.Visible = pageaction_deletepage.Visible = false;
                    div_warning.Visible = div_success.Visible = div_error.Visible = false;
                    div_information.Visible = true; label_information.Text = "<b>Note:</b> only basic html allowed in page content. html, php or other text not supported";
                }
                else if (action == "editpage")
                {
                    if (page != "null")
                    {
                        if (DatabaseControls.Validate_PageManager_PageId(page))
                        {
                            pageaction_editpage.Visible = panel_allowedhtml.Visible = true; pageaction_default.Visible = pageaction_addnew.Visible = pageaction_deletepage.Visible = false;
                            if (!IsPostBack)
                            {
                                editpage_id.Text = page;
                                string pagetitle = DatabaseControls.GetValues_PageManager_PageTitle(page);
                                string pagecontent = DatabaseControls.GetValues_PageManager_PageContent(page);
                                try { pagecontent = pagecontent.Replace("<br/>", "[br]").Replace("<b>", "[b]").Replace("</b>", "[/b]").Replace("<u>", "[u]").Replace("</u>", "[/u]").Replace("<strong>", "[strong]").Replace("</strong>", "[/strong]").Replace("<big>", "[big]").Replace("</big>", "[/big]").Replace("<small>", "[small]").Replace("</small>", "[/small]").Replace("<ul>", "[ul]").Replace("</ul>", "[/ul]").Replace("<ol>", "[ol]").Replace("</ol>", "[/ol]").Replace("<li>", "[li]").Replace("</li>", "[/li]").Replace("<mark>", "[mark]").Replace("</mark>", "[/mark]").Replace("<del>", "[del]").Replace("</del>", "[/del]").Replace("<ins>", "[ins]").Replace("</ins>", "[/ins]").Replace("<sub>", "[sub]").Replace("</sub>", "[/sub]").Replace("<sup>", "[sup]").Replace("</sup>", "[/sup]").Replace("<table>", "[table]").Replace("</table>", "[/table]").Replace("<tr>", "[tr]").Replace("</tr>", "[/tr]").Replace("<td>", "[td]").Replace("</td>", "[/td]"); }
                                catch (Exception) { }
                                editpage_title.Text = pagetitle;
                                editpage_content.InnerText = pagecontent;
                            };
                        }
                        else { div_error.Visible = true; div_information.Visible = div_success.Visible = div_warning.Visible = false; label_error.Text = "Unable to Perform Action due to Page not Found!"; }
                    }
                    else { div_error.Visible = true; div_information.Visible = div_success.Visible = div_warning.Visible = false; label_error.Text = "Unable to Perform Action due to Invalid Request!"; }
                }
                else if (action == "deletepage")
                {
                    if (page != "null")
                    {
                        if (DatabaseControls.Validate_PageManager_PageId(page))
                        {
                            pageaction_deletepage.Visible = true; pageaction_default.Visible = pageaction_addnew.Visible = pageaction_editpage.Visible = panel_allowedhtml.Visible = false;
                            label_deletepage_id.Text = page;
                            golink_editpage.NavigateUrl = MasterSettings.PortalPage_PageManager + "?action=editpage&page=" + page + "";

                            string pagetitle = DatabaseControls.GetValues_PageManager_PageTitle(page);
                            string pagecontent = DatabaseControls.GetValues_PageManager_PageContent(page);
                            try { pagecontent = pagecontent.Replace("<br/>", "[br]").Replace("<b>", "[b]").Replace("</b>", "[/b]").Replace("<u>", "[u]").Replace("</u>", "[/u]").Replace("<strong>", "[strong]").Replace("</strong>", "[/strong]").Replace("<big>", "[big]").Replace("</big>", "[/big]").Replace("<small>", "[small]").Replace("</small>", "[/small]").Replace("<ul>", "[ul]").Replace("</ul>", "[/ul]").Replace("<ol>", "[ol]").Replace("</ol>", "[/ol]").Replace("<li>", "[li]").Replace("</li>", "[/li]").Replace("<mark>", "[mark]").Replace("</mark>", "[/mark]").Replace("<del>", "[del]").Replace("</del>", "[/del]").Replace("<ins>", "[ins]").Replace("</ins>", "[/ins]").Replace("<sub>", "[sub]").Replace("</sub>", "[/sub]").Replace("<sup>", "[sup]").Replace("</sup>", "[/sup]").Replace("<table>", "[table]").Replace("</table>", "[/table]").Replace("<tr>", "[tr]").Replace("</tr>", "[/tr]").Replace("<td>", "[td]").Replace("</td>", "[/td]"); }
                            catch (Exception) { }
                            editpage_title.Text = pagetitle;
                            editpage_content.InnerText = pagecontent;
                            label_deletepage_title.Text = pagetitle;
                            label_deletepage_content.Text = pagecontent;
                        }
                        else { div_error.Visible = true; div_information.Visible = div_success.Visible = div_warning.Visible = false; label_error.Text = "Unable to Perform Action due to Page not Found!"; }
                    }
                    else { div_error.Visible = true; div_information.Visible = div_success.Visible = div_warning.Visible = false; label_error.Text = "Unable to Perform Action due to Invalid Request!"; }
                }
                else { div_error.Visible = true; div_information.Visible = div_success.Visible = div_warning.Visible = false; label_error.Text = "Unable to Perform Action due to Invalid Request!"; }
            }
            else { pageaction_default.Visible = true; pageaction_editpage.Visible = pageaction_addnew.Visible = pageaction_deletepage.Visible = panel_allowedhtml.Visible = false; }

            
            // default page action
            try
            {
                string SQLQuery = "SELECT page_id,page_views,page_title,page_date,page_update from " + MasterSettings.Function_PageManager + "";
                SQLCn.Open();
                SqlCommand SQLCmd = new SqlCommand(SQLQuery, SQLCn);
                SqlDataReader SQLDR = SQLCmd.ExecuteReader();

                // table header elements
                TableHeaderRow THR = new TableHeaderRow();
                pagefunction_main.Rows.Add(THR);
                TableHeaderCell THC1 = new TableHeaderCell();
                THC1.Text = "Page Path";
                THR.Cells.Add(THC1);
                TableHeaderCell THC2 = new TableHeaderCell();
                THC2.Text = "Page Title";
                THR.Cells.Add(THC2);
                TableHeaderCell THC3 = new TableHeaderCell();
                THC3.Text = "Page Views";
                THR.Cells.Add(THC3);
                TableHeaderCell THC4 = new TableHeaderCell();
                THC4.Text = "Created";
                THR.Cells.Add(THC4);
                TableHeaderCell THC5 = new TableHeaderCell();
                THC5.Text = "Last Update";
                THR.Cells.Add(THC5);
                TableHeaderCell THC6 = new TableHeaderCell();
                THC6.Text = "Page Options";
                THR.Cells.Add(THC6);

                while (SQLDR.Read())
                {
                    // table content elements
                    TableRow TR = new TableRow();
                    pagefunction_main.Rows.Add(TR);
                    TableCell TC1 = new TableCell();
                    TC1.Text = "<a href='" + MasterSettings.PortalPage_Home + "?page=" + SQLDR["page_id"].ToString() + "'>" + SQLDR["page_id"].ToString() + "</a>";
                    TR.Cells.Add(TC1);
                    TableCell TC2 = new TableCell();
                    TC2.Text = SQLDR["page_title"].ToString();
                    TR.Cells.Add(TC2);
                    TableCell TC3 = new TableCell();
                    TC3.Text = SQLDR["page_views"].ToString();
                    TR.Cells.Add(TC3);
                    TableCell TC4 = new TableCell();
                    TC4.Text = SQLDR["page_date"].ToString();
                    TR.Cells.Add(TC4);
                    TableCell TC5 = new TableCell();
                    TC5.Text = SQLDR["page_update"].ToString();
                    TR.Cells.Add(TC5);
                    TableCell TC6 = new TableCell();
                    TC6.Text = "<a href='" + MasterSettings.PortalPage_PageManager + "?action=editpage&page=" + SQLDR["page_id"].ToString() + "' class='btn btn-xs btn-success'><font color='white'>Edit Page</font></a> <a href='" + MasterSettings.PortalPage_PageManager + "?action=deletepage&page=" + SQLDR["page_id"].ToString() + "' class='btn btn-xs btn-danger'><font color='white'>Delete Page</font></a>";
                    TR.Cells.Add(TC6);
                }
            }
            catch (Exception) { }
            finally { SQLCn.Close(); }
        };
    }
    protected void button_addnewpage_Click(object sender, EventArgs e)
    {
        string pageid, pagename, pagetitle, pagecontent;
        pageid = input_pageid.Text;
        pagename = pagetitle = input_pagetitle.Text;
        pagecontent = input_pagecontent.InnerHtml;
        if (pagetitle == "" || pagetitle == null || pagetitle.Length < 1) { pagename = pagetitle = "Untitled"; };
        if (pagecontent == "" || pagecontent == null || pagecontent.Length < 1) { pagecontent = "Page not Published"; };
        try { pagecontent = pagecontent.Replace("[br]", "<br/>").Replace("[b]", "<b>").Replace("[/b]", "</b>").Replace("[u]", "<u>").Replace("[/u]", "</u>").Replace("[strong]", "<strong>").Replace("[/strong]", "</strong>").Replace("[big]", "<big>").Replace("[/big]", "</big>").Replace("[small]", "<small>").Replace("[/small]", "</small>").Replace("[ul]", "<ul>").Replace("[/ul]", "</ul>").Replace("[ol]", "<ol>").Replace("[/ol]", "</ol>").Replace("[li]", "<li>").Replace("[/li]", "</li>").Replace("[br/]", "<br/>").Replace("[mark]", "<mark>").Replace("[/mark]", "</mark>").Replace("[del]", "<del>").Replace("[/del]", "</del>").Replace("[ins]", "<ins>").Replace("[/ins]", "</ins>").Replace("[sub]", "<sub>").Replace("[/sub]", "</sub>").Replace("[sup]", "<sup>").Replace("[/sup]", "</sup>").Replace("[table]", "<table>").Replace("[/table]", "</table>").Replace("[tr]", "<tr>").Replace("[/tr]", "</tr>").Replace("[td]", "<td>").Replace("[/td]", "</td>"); }
        catch (Exception) { }

        if (DatabaseControls.ValidateInputValue(pageid))
        {
            if (!DatabaseControls.Validate_PageManager_PageId(pageid))
            {
                if (DatabaseControls.InsertValues_PageManager(pageid, pagename, pagetitle, pagecontent))
                {
                    pageaction_default.Visible = true; pageaction_addnew.Visible = pageaction_deletepage.Visible = pageaction_editpage.Visible = panel_allowedhtml.Visible = false;
                    div_error.Visible = div_information.Visible = div_warning.Visible = false; div_success.Visible = true; label_success.Text = "new page created successfully... <a href='" + MasterSettings.PortalPage_Home + "?page=" + pageid + "'>Click Here to Visit</a>";
                }
                else { div_error.Visible = true; div_information.Visible = div_success.Visible = div_warning.Visible = false; label_error.Text = "something mistake! unable to create new page"; }
            }
            else { div_error.Visible = true; div_information.Visible = div_success.Visible = div_warning.Visible = false; label_error.Text = "page url already exists! please use another page url"; }
        }
        else { div_error.Visible = true; div_information.Visible = div_success.Visible = div_warning.Visible = false; label_error.Text = "Please Enter Valid Page URL (ex: contactus)"; }
    }
    protected void button_editpage_Click(object sender, EventArgs e)
    {
        string pageid, pagename, pagetitle, pagecontent;
        pageid = editpage_id.Text;
        pagename = pagetitle = editpage_title.Text;
        pagecontent = editpage_content.InnerText;
        if (pageid == "" || pageid == null || pageid.Length < 1) { pageid = page; };
        if (pagetitle == "" || pagetitle == null || pagetitle.Length < 1) { pagename = pagetitle = DatabaseControls.GetValues_PageManager_PageTitle(page); };
        if (pagecontent == "" || pagecontent == null || pagecontent.Length < 1) { pagecontent = DatabaseControls.GetValues_PageManager_PageContent(page); };
        try { pagecontent = pagecontent.Replace("[br]", "<br/>").Replace("[b]", "<b>").Replace("[/b]", "</b>").Replace("[u]", "<u>").Replace("[/u]", "</u>").Replace("[strong]", "<strong>").Replace("[/strong]", "</strong>").Replace("[big]", "<big>").Replace("[/big]", "</big>").Replace("[small]", "<small>").Replace("[/small]", "</small>").Replace("[ul]", "<ul>").Replace("[/ul]", "</ul>").Replace("[ol]", "<ol>").Replace("[/ol]", "</ol>").Replace("[li]", "<li>").Replace("[/li]", "</li>").Replace("[br/]", "<br/>").Replace("[mark]", "<mark>").Replace("[/mark]", "</mark>").Replace("[del]", "<del>").Replace("[/del]", "</del>").Replace("[ins]", "<ins>").Replace("[/ins]", "</ins>").Replace("[sub]", "<sub>").Replace("[/sub]", "</sub>").Replace("[sup]", "<sup>").Replace("[/sup]", "</sup>").Replace("[table]", "<table>").Replace("[/table]", "</table>").Replace("[tr]", "<tr>").Replace("[/tr]", "</tr>").Replace("[td]", "<td>").Replace("[/td]", "</td>"); }
        catch (Exception) { }

        if (DatabaseControls.ValidateInputValue(pageid))
        {
            if (pageid == page || !DatabaseControls.Validate_PageManager_PageId(pageid))
            {
                if (DatabaseControls.UpdateValue_PageManager(page, pageid, pagename, pagetitle, pagecontent)) { pageaction_default.Visible = true; pageaction_editpage.Visible = pageaction_deletepage.Visible = pageaction_addnew.Visible = panel_allowedhtml.Visible = false; div_error.Visible = div_information.Visible = div_warning.Visible = false; div_success.Visible = true; label_success.Text = "page updated successfully... <a href='" + MasterSettings.PortalPage_Home + "?page=" + pageid + "'>Click Here to Visit</a>"; }
                else { div_error.Visible = true; div_information.Visible = div_success.Visible = div_warning.Visible = false; label_error.Text = "something mistake! unable to create new page"; }
            }
            else { div_error.Visible = true; div_information.Visible = div_success.Visible = div_warning.Visible = false; label_error.Text = "page url already exists! please use another page url"; }
        }
        else { div_error.Visible = true; div_information.Visible = div_success.Visible = div_warning.Visible = false; label_error.Text = "Please Enter Valid Page URL (ex: contactus)"; }
    }
    protected void button_deletepage_Click(object sender, EventArgs e)
    {        
        if (DatabaseControls.ValidateInputValue(page))
        {
            if (DatabaseControls.Validate_PageManager_PageId(page))
            {
                if (DatabaseControls.DeleteFunction_PageManager_DeleteSingleRecord(page)) { pageaction_default.Visible = true; pageaction_editpage.Visible = pageaction_deletepage.Visible = pageaction_addnew.Visible = panel_allowedhtml.Visible = false; div_error.Visible = div_information.Visible = div_warning.Visible = false; div_success.Visible = true; label_success.Text = "page deleted successfully... <a href='" + MasterSettings.PortalPage_PageManager + "'>Click Here to Visit PageManager</a>"; }
                else { div_error.Visible = true; div_information.Visible = div_success.Visible = div_warning.Visible = false; label_error.Text = "something mistake! unable to delete page"; }
            }
            else { div_error.Visible = true; div_information.Visible = div_success.Visible = div_warning.Visible = false; label_error.Text = "page url not exists!"; }
        }
        else { div_error.Visible = true; div_information.Visible = div_success.Visible = div_warning.Visible = false; label_error.Text = "Unable to Perform Action! Invalid Request"; }
    }
}